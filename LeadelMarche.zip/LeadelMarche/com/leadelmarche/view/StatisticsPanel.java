package com.leadelmarche.view;

import com.leadelmarche.service.StatisticsService;
import javax.swing.*;
import java.awt.*;

public class StatisticsPanel extends JPanel {
    private StatisticsService statisticsService;

    public StatisticsPanel() {
        this.statisticsService = new StatisticsService();
        setLayout(new GridLayout(3, 2, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Add statistics labels
        add(createStatPanel("Total Sales", String.valueOf(statisticsService.getTotalSalesCount())));
        add(createStatPanel("Total Revenue", String.format("%.2f", statisticsService.getTotalSalesAmount())));
        add(createStatPanel("Average Sale", String.format("%.2f", statisticsService.getAverageSaleAmount())));
        add(createStatPanel("Total Clients", String.valueOf(statisticsService.getTotalClients())));
        add(createStatPanel("Total Employees", String.valueOf(statisticsService.getTotalEmployees())));
        add(createStatPanel("Total Products", String.valueOf(statisticsService.getTotalProducts())));
    }

    private JPanel createStatPanel(String title, String value) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));

        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);

        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(valueLabel, BorderLayout.CENTER);

        return panel;
    }
}
