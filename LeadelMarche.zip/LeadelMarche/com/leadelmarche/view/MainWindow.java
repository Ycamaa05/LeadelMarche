package com.leadelmarche.view;

import javax.swing.*;

public class MainWindow extends JFrame {
    private JTabbedPane tabbedPane;

    public MainWindow() {
        setTitle("LeadelMarche - Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        tabbedPane = new JTabbedPane();
        
        // Add tabs for different modules
        tabbedPane.addTab("Clients", new ClientPanel());
        tabbedPane.addTab("Personnel", new PersonnelPanel());
        tabbedPane.addTab("Inventory", new InventoryPanel());
        tabbedPane.addTab("Sales", new SalesPanel());
        tabbedPane.addTab("Statistics", new StatisticsPanel());

        add(tabbedPane);
    }
}
