package com.leadelmarche.view;

import com.leadelmarche.model.Employee;
import com.leadelmarche.service.PersonnelService;
import javax.swing.*;
import java.awt.*;

public class PersonnelPanel extends JPanel {
    private PersonnelService personnelService;
    private JTable employeeTable;
    private JButton addButton, editButton, deleteButton;

    public PersonnelPanel() {
        this.personnelService = new PersonnelService();
        setLayout(new BorderLayout());

        // Create buttons panel
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add Employee");
        editButton = new JButton("Edit Employee");
        deleteButton = new JButton("Delete Employee");

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Create table for employees
        employeeTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(employeeTable);

        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setupListeners();
        refreshTable();
    }

    private void setupListeners() {
        addButton.addActionListener(e -> showEmployeeDialog(null));
        editButton.addActionListener(e -> {
            int row = employeeTable.getSelectedRow();
            if (row >= 0) {
                showEmployeeDialog(personnelService.getAllEmployees().get(row));
            }
        });
        deleteButton.addActionListener(e -> {
            int row = employeeTable.getSelectedRow();
            if (row >= 0) {
                personnelService.removeEmployee(personnelService.getAllEmployees().get(row).getId());
                refreshTable();
            }
        });
    }

    private void showEmployeeDialog(Employee employee) {
        new EmployeeEditor(this, employee);
    }

    public void refreshTable() {
        // Refresh table data
    }

    public static class EmployeeEditor extends JDialog {
        public EmployeeEditor(PersonnelPanel parent, Employee employee) {
            setTitle(employee == null ? "Add Employee" : "Edit Employee");
            setModal(true);
            setSize(300, 200);
        }
    }
}
