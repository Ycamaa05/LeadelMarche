package com.leadelmarche.view;

import com.leadelmarche.model.Product;
import com.leadelmarche.service.InventoryService;
import javax.swing.*;
import java.awt.*;

public class InventoryPanel extends JPanel {
    private InventoryService inventoryService;
    private JTable productTable;
    private JButton addButton, editButton, deleteButton;

    public InventoryPanel() {
        this.inventoryService = new InventoryService();
        setLayout(new BorderLayout());

        // Create buttons panel
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add Product");
        editButton = new JButton("Edit Product");
        deleteButton = new JButton("Delete Product");

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Create table for products
        productTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(productTable);

        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setupListeners();
        refreshTable();
    }

    private void setupListeners() {
        addButton.addActionListener(e -> showProductDialog(null));
        editButton.addActionListener(e -> {
            int row = productTable.getSelectedRow();
            if (row >= 0) {
                showProductDialog(inventoryService.getAllProducts().get(row));
            }
        });
        deleteButton.addActionListener(e -> {
            int row = productTable.getSelectedRow();
            if (row >= 0) {
                inventoryService.removeProduct(inventoryService.getAllProducts().get(row).getId());
                refreshTable();
            }
        });
    }

    private void showProductDialog(Product product) {
        new ProductEditor(this, product);
    }

    public void refreshTable() {
        // Refresh table data
    }

    public static class ProductEditor extends JDialog {
        public ProductEditor(InventoryPanel parent, Product product) {
            setTitle(product == null ? "Add Product" : "Edit Product");
            setModal(true);
            setSize(300, 250);
        }
    }
}
