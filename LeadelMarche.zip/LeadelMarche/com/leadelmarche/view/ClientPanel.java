package com.leadelmarche.view;

import com.leadelmarche.model.Client;
import com.leadelmarche.service.ClientService;
import javax.swing.*;
import java.awt.*;

public class ClientPanel extends JPanel {
    private ClientService clientService;
    private JTable clientTable;
    private JButton addButton, editButton, deleteButton;

    public ClientPanel() {
        this.clientService = new ClientService();
        setLayout(new BorderLayout());

        // Create buttons panel
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add Client");
        editButton = new JButton("Edit Client");
        deleteButton = new JButton("Delete Client");

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Create table for clients
        clientTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(clientTable);

        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setupListeners();
        refreshTable();
    }

    private void setupListeners() {
        addButton.addActionListener(e -> showClientDialog(null));
        editButton.addActionListener(e -> {
            int row = clientTable.getSelectedRow();
            if (row >= 0) {
                showClientDialog(clientService.getAllClients().get(row));
            }
        });
        deleteButton.addActionListener(e -> {
            int row = clientTable.getSelectedRow();
            if (row >= 0) {
                clientService.removeClient(clientService.getAllClients().get(row).getId());
                refreshTable();
            }
        });
    }

    private void showClientDialog(Client client) {
        new ClientEditor(this, client);
    }

    public void refreshTable() {
        // Refresh table data
    }

    public static class ClientEditor extends JDialog {
        public ClientEditor(ClientPanel parent, Client client) {
            setTitle(client == null ? "Add Client" : "Edit Client");
            setModal(true);
            setSize(300, 200);
        }
    }
}
