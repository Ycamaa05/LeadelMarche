package com.leadelmarche.view;

import com.leadelmarche.service.SalesService;
import javax.swing.*;
import java.awt.*;

public class SalesPanel extends JPanel {
    private SalesService salesService;
    private JTable salesTable;
    private JButton newSaleButton, viewDetailsButton;

    public SalesPanel() {
        this.salesService = new SalesService();
        setLayout(new BorderLayout());

        // Create buttons panel
        JPanel buttonPanel = new JPanel();
        newSaleButton = new JButton("New Sale");
        viewDetailsButton = new JButton("View Details");

        buttonPanel.add(newSaleButton);
        buttonPanel.add(viewDetailsButton);

        // Create table for sales
        salesTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(salesTable);

        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setupListeners();
    }

    private void setupListeners() {
        newSaleButton.addActionListener(e -> JOptionPane.showMessageDialog(this, "New Sale feature coming soon"));
        viewDetailsButton.addActionListener(e -> JOptionPane.showMessageDialog(this, "View Details feature coming soon"));
    }
}
