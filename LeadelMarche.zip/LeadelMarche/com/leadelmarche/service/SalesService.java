package com.leadelmarche.service;

import com.leadelmarche.model.Sale;
import java.util.List;

public class SalesService {
    private DataStore dataStore;

    public SalesService() {
        this.dataStore = DataStore.getInstance();
    }

    public void addSale(Sale sale) {
        dataStore.getSales().add(sale);
    }

    public void removeSale(String saleId) {
        dataStore.getSales().removeIf(s -> s.getId().equals(saleId));
    }

    public Sale getSale(String saleId) {
        return dataStore.getSales().stream()
            .filter(s -> s.getId().equals(saleId))
            .findFirst()
            .orElse(null);
    }

    public List<Sale> getAllSales() {
        return dataStore.getSales();
    }

    public void updateSale(Sale sale) {
        Sale existing = getSale(sale.getId());
        if (existing != null) {
            existing.setClientId(sale.getClientId());
            existing.setDate(sale.getDate());
            existing.setItems(sale.getItems());
            existing.setTotal(sale.getTotal());
        }
    }
}
