package com.leadelmarche.service;

import com.leadelmarche.model.Employee;
import java.util.List;

public class PersonnelService {
    private DataStore dataStore;

    public PersonnelService() {
        this.dataStore = DataStore.getInstance();
    }

    public void addEmployee(Employee employee) {
        dataStore.getEmployees().add(employee);
    }

    public void removeEmployee(String employeeId) {
        dataStore.getEmployees().removeIf(e -> e.getId().equals(employeeId));
    }

    public Employee getEmployee(String employeeId) {
        return dataStore.getEmployees().stream()
            .filter(e -> e.getId().equals(employeeId))
            .findFirst()
            .orElse(null);
    }

    public List<Employee> getAllEmployees() {
        return dataStore.getEmployees();
    }

    public void updateEmployee(Employee employee) {
        Employee existing = getEmployee(employee.getId());
        if (existing != null) {
            existing.setName(employee.getName());
            existing.setPosition(employee.getPosition());
            existing.setSalary(employee.getSalary());
        }
    }
}
