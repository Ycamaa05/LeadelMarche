package com.leadelmarche.service;

import com.leadelmarche.model.Client;
import java.util.List;

public class ClientService {
    private DataStore dataStore;

    public ClientService() {
        this.dataStore = DataStore.getInstance();
    }

    public void addClient(Client client) {
        dataStore.getClients().add(client);
    }

    public void removeClient(String clientId) {
        dataStore.getClients().removeIf(c -> c.getId().equals(clientId));
    }

    public Client getClient(String clientId) {
        return dataStore.getClients().stream()
            .filter(c -> c.getId().equals(clientId))
            .findFirst()
            .orElse(null);
    }

    public List<Client> getAllClients() {
        return dataStore.getClients();
    }

    public void updateClient(Client client) {
        Client existing = getClient(client.getId());
        if (existing != null) {
            existing.setName(client.getName());
            existing.setEmail(client.getEmail());
            existing.setPhone(client.getPhone());
        }
    }
}
