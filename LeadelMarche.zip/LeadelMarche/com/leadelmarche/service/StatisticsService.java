package com.leadelmarche.service;

import com.leadelmarche.model.Sale;
import java.util.List;

public class StatisticsService {
    private DataStore dataStore;

    public StatisticsService() {
        this.dataStore = DataStore.getInstance();
    }

    public double getTotalSalesAmount() {
        return dataStore.getSales().stream()
            .mapToDouble(Sale::getTotal)
            .sum();
    }

    public int getTotalSalesCount() {
        return dataStore.getSales().size();
    }

    public double getAverageSaleAmount() {
        List<Sale> sales = dataStore.getSales();
        if (sales.isEmpty()) {
            return 0;
        }
        return getTotalSalesAmount() / sales.size();
    }

    public int getTotalClients() {
        return dataStore.getClients().size();
    }

    public int getTotalEmployees() {
        return dataStore.getEmployees().size();
    }

    public int getTotalProducts() {
        return dataStore.getProducts().size();
    }
}
