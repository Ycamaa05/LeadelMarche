package com.leadelmarche.service;

import com.leadelmarche.model.*;
import java.util.*;

public class DataStore {
    private static DataStore instance;
    private List<Client> clients;
    private List<Employee> employees;
    private List<Product> products;
    private List<Promotion> promotions;
    private List<Sale> sales;

    private DataStore() {
        this.clients = new ArrayList<>();
        this.employees = new ArrayList<>();
        this.products = new ArrayList<>();
        this.promotions = new ArrayList<>();
        this.sales = new ArrayList<>();
    }

    public static DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
        }
        return instance;
    }

    public List<Client> getClients() {
        return clients;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public List<Product> getProducts() {
        return products;
    }

    public List<Promotion> getPromotions() {
        return promotions;
    }

    public List<Sale> getSales() {
        return sales;
    }
}
