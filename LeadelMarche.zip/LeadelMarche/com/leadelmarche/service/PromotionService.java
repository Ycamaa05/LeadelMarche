package com.leadelmarche.service;

import com.leadelmarche.model.Promotion;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class PromotionService {
    private DataStore dataStore;

    public PromotionService() {
        this.dataStore = DataStore.getInstance();
    }

    public void addPromotion(Promotion promotion) {
        dataStore.getPromotions().add(promotion);
    }

    public void removePromotion(String promotionId) {
        dataStore.getPromotions().removeIf(p -> p.getId().equals(promotionId));
    }

    public Promotion getPromotion(String promotionId) {
        return dataStore.getPromotions().stream()
            .filter(p -> p.getId().equals(promotionId))
            .findFirst()
            .orElse(null);
    }

    public List<Promotion> getAllPromotions() {
        return dataStore.getPromotions();
    }

    public List<Promotion> getActivePromotions(LocalDate date) {
        return dataStore.getPromotions().stream()
            .filter(p -> !date.isBefore(p.getStartDate()) && !date.isAfter(p.getEndDate()))
            .collect(Collectors.toList());
    }

    public void updatePromotion(Promotion promotion) {
        Promotion existing = getPromotion(promotion.getId());
        if (existing != null) {
            existing.setName(promotion.getName());
            existing.setType(promotion.getType());
            existing.setValue(promotion.getValue());
            existing.setStartDate(promotion.getStartDate());
            existing.setEndDate(promotion.getEndDate());
        }
    }
}
