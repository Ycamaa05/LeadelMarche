package com.leadelmarche.service;

import com.leadelmarche.model.Product;
import java.util.List;

public class InventoryService {
    private DataStore dataStore;

    public InventoryService() {
        this.dataStore = DataStore.getInstance();
    }

    public void addProduct(Product product) {
        dataStore.getProducts().add(product);
    }

    public void removeProduct(String productId) {
        dataStore.getProducts().removeIf(p -> p.getId().equals(productId));
    }

    public Product getProduct(String productId) {
        return dataStore.getProducts().stream()
            .filter(p -> p.getId().equals(productId))
            .findFirst()
            .orElse(null);
    }

    public List<Product> getAllProducts() {
        return dataStore.getProducts();
    }

    public void updateProduct(Product product) {
        Product existing = getProduct(product.getId());
        if (existing != null) {
            existing.setName(product.getName());
            existing.setPrice(product.getPrice());
            existing.setQuantity(product.getQuantity());
            existing.setType(product.getType());
        }
    }

    public boolean isInStock(String productId, int quantity) {
        Product product = getProduct(productId);
        return product != null && product.getQuantity() >= quantity;
    }
}
