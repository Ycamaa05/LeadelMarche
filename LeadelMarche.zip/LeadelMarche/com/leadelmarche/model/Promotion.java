package com.leadelmarche.model;

import java.time.LocalDate;

public class Promotion {
    public enum PromotionType {
        DISCOUNT, BUY_ONE_GET_ONE, PERCENTAGE_OFF, FIXED_PRICE
    }

    private String id;
    private String name;
    private PromotionType type;
    private double value;
    private LocalDate startDate;
    private LocalDate endDate;

    public Promotion(String id, String name, PromotionType type, double value, 
                     LocalDate startDate, LocalDate endDate) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.value = value;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PromotionType getType() {
        return type;
    }

    public void setType(PromotionType type) {
        this.type = type;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}
