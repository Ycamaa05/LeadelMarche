package com.leadelmarche.model;

import java.time.LocalDate;
import java.util.List;

public class Sale {
    private String id;
    private String clientId;
    private LocalDate date;
    private List<SaleItem> items;
    private double total;

    public Sale(String id, String clientId, LocalDate date, List<SaleItem> items, double total) {
        this.id = id;
        this.clientId = clientId;
        this.date = date;
        this.items = items;
        this.total = total;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public List<SaleItem> getItems() {
        return items;
    }

    public void setItems(List<SaleItem> items) {
        this.items = items;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
