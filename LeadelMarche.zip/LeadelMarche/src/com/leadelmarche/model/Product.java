package com.leadelmarche.model;

public class Product {
    public enum ProductType {ALIMENTS, MEDECINES, ELECTRONIQUE, AUTRES}

    private String id;
    private String name;
    private String description;
    private ProductType type;
    private double unitPrice;
    private String originCountry;
    private double tvaPercent;
    private double stockQuantity;
    private String supplierName;
    private String barcode;
    private boolean active;
    private boolean soldByWeight;
    private double expectedWeight;
    private double weightTolerance;
    private boolean requiresBalanceValidation;

    public Product(String id, String name, String description, ProductType type, double unitPrice, String originCountry,
                   double tvaPercent, double stockQuantity, String supplierName, String barcode, boolean soldByWeight, boolean active) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.type = type;
        this.unitPrice = unitPrice;
        this.originCountry = originCountry;
        this.tvaPercent = tvaPercent;
        this.stockQuantity = stockQuantity;
        this.supplierName = supplierName;
        this.barcode = barcode;
        this.active = active;
        this.soldByWeight = soldByWeight;
        this.expectedWeight = 0.0;
        this.weightTolerance = 0.05;
        this.requiresBalanceValidation = false;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public ProductType getType() {
        return type;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public String getOriginCountry() {
        return originCountry;
    }

    public double getTvaPercent() {
        return tvaPercent;
    }

    public double getStockQuantity() {
        return stockQuantity;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public String getBarcode() {
        return barcode;
    }

    public boolean isActive() {
        return active;
    }

    public boolean isSoldByWeight() {
        return soldByWeight;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setType(ProductType type) {
        this.type = type;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public void setOriginCountry(String originCountry) {
        this.originCountry = originCountry;
    }

    public void setTvaPercent(double tvaPercent) {
        this.tvaPercent = tvaPercent;
    }

    public void setStockQuantity(double stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setSoldByWeight(boolean soldByWeight) {
        this.soldByWeight = soldByWeight;
    }

    public double getExpectedWeight() {
        return expectedWeight;
    }

    public void setExpectedWeight(double expectedWeight) {
        this.expectedWeight = expectedWeight;
    }

    public double getWeightTolerance() {
        return weightTolerance;
    }

    public void setWeightTolerance(double weightTolerance) {
        this.weightTolerance = weightTolerance;
    }

    public boolean isRequiresBalanceValidation() {
        return requiresBalanceValidation;
    }

    public void setRequiresBalanceValidation(boolean requiresBalanceValidation) {
        this.requiresBalanceValidation = requiresBalanceValidation;
    }

    public double getPriceWithTva() {
        return unitPrice * (1 + tvaPercent / 100.0);
    }

    @Override
    public String toString() {
        return id + ";" + name + ";" + description + ";" + type + ";" + unitPrice + ";" + originCountry + ";" + tvaPercent + ";" + stockQuantity + ";" + supplierName + ";" + barcode + ";" + active + ";" + soldByWeight;
    }

    public static Product fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 12) return null;
        return new Product(parts[0], parts[1], parts[2], ProductType.valueOf(parts[3]),
                Double.parseDouble(parts[4]), parts[5], Double.parseDouble(parts[6]),
                Double.parseDouble(parts[7]), parts[8], parts[9], Boolean.parseBoolean(parts[10]), Boolean.parseBoolean(parts[11]));
    }
}
