package com.leadelmarche.model;

import java.time.LocalDateTime;

public class Statistic {
    public enum StatisticType {LOYALTY_CARDS, PRODUCTS_SOLD, ABSENCES, REVENUE, INVENTORY, CUSTOM}

    private String id;
    private String name;
    private StatisticType type;
    private String description;
    private LocalDateTime createdDate;
    private String query;

    public Statistic(String id, String name, StatisticType type, String description, LocalDateTime createdDate, String query) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.description = description;
        this.createdDate = createdDate;
        this.query = query;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public StatisticType getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public String getQuery() {
        return query;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    @Override
    public String toString() {
        return id + ";" + name + ";" + type + ";" + description + ";" + createdDate + ";" + query;
    }
}
