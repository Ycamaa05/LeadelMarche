package com.leadelmarche.model;

import java.time.LocalDate;

public class EmployeeContract {
    public enum ContractType {CDI, CDI_STUDENT, CDD, INTERIM}

    private String id;
    private String employeeId;
    private ContractType type;
    private int weeklyHours;
    private LocalDate startDate;
    private LocalDate endDate;
    private double hourlyRate;
    private boolean active;

    public EmployeeContract(String id, String employeeId, ContractType type, int weeklyHours, 
                           LocalDate startDate, LocalDate endDate, double hourlyRate, boolean active) {
        this.id = id;
        this.employeeId = employeeId;
        this.type = type;
        this.weeklyHours = weeklyHours;
        this.startDate = startDate;
        this.endDate = endDate;
        this.hourlyRate = hourlyRate;
        this.active = active;
    }

    public String getId() {
        return id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public ContractType getType() {
        return type;
    }

    public int getWeeklyHours() {
        return weeklyHours;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public boolean isActive() {
        return active;
    }

    public void setWeeklyHours(int weeklyHours) {
        this.weeklyHours = weeklyHours;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return id + ";" + employeeId + ";" + type + ";" + weeklyHours + ";" + startDate + ";" + endDate + ";" + hourlyRate + ";" + active;
    }

    public static EmployeeContract fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 8) return null;
        return new EmployeeContract(parts[0], parts[1], ContractType.valueOf(parts[2]), Integer.parseInt(parts[3]),
                LocalDate.parse(parts[4]), LocalDate.parse(parts[5]), Double.parseDouble(parts[6]), Boolean.parseBoolean(parts[7]));
    }
}
