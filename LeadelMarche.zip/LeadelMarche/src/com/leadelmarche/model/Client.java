package com.leadelmarche.model;

public class Client {
    private String id;
    private String firstName;
    private String lastName;
    private String loyaltyCardNumber;
    private String email;
    private String postalCode;
    private boolean active;

    public Client(String id, String firstName, String lastName, String loyaltyCardNumber, String email, String postalCode, boolean active) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.loyaltyCardNumber = loyaltyCardNumber;
        this.email = email;
        this.postalCode = postalCode;
        this.active = active;
    }

    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getLoyaltyCardNumber() {
        return loyaltyCardNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public boolean isActive() {
        return active;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setLoyaltyCardNumber(String loyaltyCardNumber) {
        this.loyaltyCardNumber = loyaltyCardNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return id + ";" + firstName + ";" + lastName + ";" + loyaltyCardNumber + ";" + email + ";" + postalCode + ";" + active;
    }

    public static Client fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 7) return null;
        return new Client(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], Boolean.parseBoolean(parts[6]));
    }
}
