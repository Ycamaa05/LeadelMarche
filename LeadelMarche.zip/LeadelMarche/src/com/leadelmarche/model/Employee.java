package com.leadelmarche.model;

public class Employee {
    private String id;
    private String firstName;
    private String lastName;
    private String personalAddress;
    private String workAddress;
    private String position;
    private String immediateSupervisor;
    private String badgeNumber;
    private int weeklyHours;
    private boolean active;

    public Employee(String id, String firstName, String lastName, String personalAddress, String workAddress,
                    String position, String immediateSupervisor, String badgeNumber, int weeklyHours, boolean active) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.personalAddress = personalAddress;
        this.workAddress = workAddress;
        this.position = position;
        this.immediateSupervisor = immediateSupervisor;
        this.badgeNumber = badgeNumber;
        this.weeklyHours = weeklyHours;
        this.active = active;
    }

    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPersonalAddress() {
        return personalAddress;
    }

    public String getWorkAddress() {
        return workAddress;
    }

    public String getPosition() {
        return position;
    }

    public String getImmediateSupervisor() {
        return immediateSupervisor;
    }

    public String getBadgeNumber() {
        return badgeNumber;
    }

    public int getWeeklyHours() {
        return weeklyHours;
    }

    public boolean isActive() {
        return active;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPersonalAddress(String personalAddress) {
        this.personalAddress = personalAddress;
    }

    public void setWorkAddress(String workAddress) {
        this.workAddress = workAddress;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setImmediateSupervisor(String immediateSupervisor) {
        this.immediateSupervisor = immediateSupervisor;
    }

    public void setBadgeNumber(String badgeNumber) {
        this.badgeNumber = badgeNumber;
    }

    public void setWeeklyHours(int weeklyHours) {
        this.weeklyHours = weeklyHours;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return id + ";" + firstName + ";" + lastName + ";" + personalAddress + ";" + workAddress + ";" + position + ";" + immediateSupervisor + ";" + badgeNumber + ";" + weeklyHours + ";" + active;
    }

    public static Employee fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 10) return null;
        return new Employee(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6], parts[7], Integer.parseInt(parts[8]), Boolean.parseBoolean(parts[9]));
    }
}
