package com.leadelmarche.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Sale {
    private String id;
    private String storeName;
    private String cashierBadge;
    private String clientLoyaltyCard;
    private List<SaleItem> items;
    private double subtotal;
    private double tvaAmount;
    private double total;
    private LocalDateTime dateTime;
    private boolean active;

    public Sale(String id, String storeName, String cashierBadge, String clientLoyaltyCard, List<SaleItem> items,
                double subtotal, double tvaAmount, double total, LocalDateTime dateTime, boolean active) {
        this.id = id;
        this.storeName = storeName;
        this.cashierBadge = cashierBadge;
        this.clientLoyaltyCard = clientLoyaltyCard;
        this.items = new ArrayList<>(items);
        this.subtotal = subtotal;
        this.tvaAmount = tvaAmount;
        this.total = total;
        this.dateTime = dateTime;
        this.active = active;
    }

    public String getId() {
        return id;
    }

    public String getStoreName() {
        return storeName;
    }

    public String getCashierBadge() {
        return cashierBadge;
    }

    public String getClientLoyaltyCard() {
        return clientLoyaltyCard;
    }

    public List<SaleItem> getItems() {
        return new ArrayList<>(items);
    }

    public double getSubtotal() {
        return subtotal;
    }

    public double getTvaAmount() {
        return tvaAmount;
    }

    public double getTotal() {
        return total;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getDateTimeString() {
        return dateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(id).append(";").append(storeName).append(";").append(cashierBadge).append(";")
                .append(clientLoyaltyCard).append(";").append(subtotal).append(";")
                .append(tvaAmount).append(";").append(total).append(";").append(getDateTimeString()).append(";")
                .append(active).append(";");
        for (SaleItem item : items) {
            builder.append(item.toString()).append("|");
        }
        return builder.toString();
    }

    public static Sale fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 10) return null;
        String id = parts[0];
        String storeName = parts[1];
        String cashierBadge = parts[2];
        String clientLoyaltyCard = parts[3];
        double subtotal = Double.parseDouble(parts[4]);
        double tvaAmount = Double.parseDouble(parts[5]);
        double total = Double.parseDouble(parts[6]);
        LocalDateTime dateTime = LocalDateTime.parse(parts[7]);
        boolean active = Boolean.parseBoolean(parts[8]);
        String itemsRaw = parts[9];
        List<SaleItem> items = new ArrayList<>();
        if (!itemsRaw.isEmpty()) {
            for (String itemString : itemsRaw.split("\\|")) {
                if (!itemString.trim().isEmpty()) {
                    SaleItem item = SaleItem.fromLine(itemString);
                    if (item != null) items.add(item);
                }
            }
        }
        return new Sale(id, storeName, cashierBadge, clientLoyaltyCard, items, subtotal, tvaAmount, total, dateTime, active);
    }
}
