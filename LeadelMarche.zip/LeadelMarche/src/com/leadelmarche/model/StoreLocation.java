package com.leadelmarche.model;

public class StoreLocation {
    private String id;
    private String name;
    private String city;
    private String address;
    private String phone;
    private String manager;
    private boolean active;

    public StoreLocation(String id, String name, String city, String address, String phone, String manager, boolean active) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.address = address;
        this.phone = phone;
        this.manager = manager;
        this.active = active;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCity() {
        return city;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getManager() {
        return manager;
    }

    public boolean isActive() {
        return active;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return id + ";" + name + ";" + city + ";" + address + ";" + phone + ";" + manager + ";" + active;
    }

    public static StoreLocation fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 7) return null;
        return new StoreLocation(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], Boolean.parseBoolean(parts[6]));
    }
}
