package com.leadelmarche.model;

import java.time.LocalDate;

public class DayOff {
    public enum DayOffType {CONGE, RTT, MALADIE, AUTRE}

    private String id;
    private String employeeId;
    private LocalDate startDate;
    private LocalDate endDate;
    private DayOffType type;
    private String reason;

    public DayOff(String id, String employeeId, LocalDate startDate, LocalDate endDate, DayOffType type, String reason) {
        this.id = id;
        this.employeeId = employeeId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.type = type;
        this.reason = reason;
    }

    public String getId() {
        return id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public DayOffType getType() {
        return type;
    }

    public String getReason() {
        return reason;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return id + ";" + employeeId + ";" + startDate + ";" + endDate + ";" + type + ";" + reason;
    }

    public static DayOff fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 6) return null;
        return new DayOff(parts[0], parts[1], LocalDate.parse(parts[2]), LocalDate.parse(parts[3]), 
                DayOffType.valueOf(parts[4]), parts[5]);
    }
}
