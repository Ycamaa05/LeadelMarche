package com.leadelmarche.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Shift {
    private String id;
    private String employeeId;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private int durationHours;
    private boolean lunchBreak;
    private int fifteenMinBreaks;

    public Shift(String id, String employeeId, LocalDate date, LocalTime startTime, LocalTime endTime, 
                 int durationHours, boolean lunchBreak, int fifteenMinBreaks) {
        this.id = id;
        this.employeeId = employeeId;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.durationHours = durationHours;
        this.lunchBreak = lunchBreak;
        this.fifteenMinBreaks = fifteenMinBreaks;
    }

    public String getId() {
        return id;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getStartTime() {
        return startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }

    public int getDurationHours() {
        return durationHours;
    }

    public boolean hasLunchBreak() {
        return lunchBreak;
    }

    public int getFifteenMinBreaks() {
        return fifteenMinBreaks;
    }

    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return id + ";" + employeeId + ";" + date + ";" + startTime + ";" + endTime + ";" + durationHours + ";" + lunchBreak + ";" + fifteenMinBreaks;
    }

    public static Shift fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 8) return null;
        return new Shift(parts[0], parts[1], LocalDate.parse(parts[2]), LocalTime.parse(parts[3]),
                LocalTime.parse(parts[4]), Integer.parseInt(parts[5]), Boolean.parseBoolean(parts[6]), Integer.parseInt(parts[7]));
    }
}
