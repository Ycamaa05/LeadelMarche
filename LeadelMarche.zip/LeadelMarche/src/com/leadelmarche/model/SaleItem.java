package com.leadelmarche.model;

public class SaleItem {
    private String id;
    private String productId;
    private String productName;
    private double quantity;
    private double unitPrice;
    private boolean soldByWeight;

    public SaleItem(String id, String productId, String productName, double quantity, double unitPrice, double totalPrice) {
        this(id, productId, productName, quantity, unitPrice, false);
    }

    public SaleItem(String productId, String productName, double quantity, double unitPrice, boolean soldByWeight) {
        this(java.util.UUID.randomUUID().toString(), productId, productName, quantity, unitPrice, soldByWeight);
    }

    public SaleItem(String id, String productId, String productName, double quantity, double unitPrice, boolean soldByWeight) {
        this.id = id;
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.soldByWeight = soldByWeight;
    }

    public String getId() {
        return id;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public boolean isSoldByWeight() {
        return soldByWeight;
    }

    public double getTotalPrice() {
        return unitPrice * quantity;
    }

    @Override
    public String toString() {
        return productId + ";" + productName + ";" + quantity + ";" + unitPrice + ";" + soldByWeight;
    }

    public static SaleItem fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 5) return null;
        return new SaleItem(parts[0], parts[1], Double.parseDouble(parts[2]), Double.parseDouble(parts[3]), Boolean.parseBoolean(parts[4]));
    }
}
