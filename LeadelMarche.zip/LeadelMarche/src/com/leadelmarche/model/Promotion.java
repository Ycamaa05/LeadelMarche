package com.leadelmarche.model;

import java.time.LocalDate;

public class Promotion {
    public enum PromotionType {DEUX_ACHETES_TROISIEME_OFFERT, POURCENTAGE_SUR_DEUXIEME, CAGNOTTE_FIDELITE, REMISE_FIXE}

    private String id;
    private String name;
    private PromotionType type;
    private double value;
    private boolean active;
    private String description;
    private LocalDate startDate;
    private LocalDate endDate;
    private boolean renewable;
    private int durationDays;
    private boolean appliedToLoyaltyCard;

    public Promotion(String id, String name, PromotionType type, double value, boolean active, String description) {
        this(id, name, type, value, active, description, LocalDate.now(), LocalDate.now().plusDays(30), false, 30, false);
    }

    public Promotion(String id, String name, PromotionType type, double value, boolean active, String description,
                     LocalDate startDate, LocalDate endDate, boolean renewable, int durationDays, boolean appliedToLoyaltyCard) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.value = value;
        this.active = active;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.renewable = renewable;
        this.durationDays = durationDays;
        this.appliedToLoyaltyCard = appliedToLoyaltyCard;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public PromotionType getType() {
        return type;
    }

    public double getValue() {
        return value;
    }

    public boolean isActive() {
        return active;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setType(PromotionType type) {
        this.type = type;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public boolean isRenewable() {
        return renewable;
    }

    public void setRenewable(boolean renewable) {
        this.renewable = renewable;
    }

    public int getDurationDays() {
        return durationDays;
    }

    public void setDurationDays(int durationDays) {
        this.durationDays = durationDays;
    }

    public boolean isAppliedToLoyaltyCard() {
        return appliedToLoyaltyCard;
    }

    public void setAppliedToLoyaltyCard(boolean appliedToLoyaltyCard) {
        this.appliedToLoyaltyCard = appliedToLoyaltyCard;
    }

    @Override
    public String toString() {
        return id + ";" + name + ";" + type + ";" + value + ";" + active + ";" + description + ";" + startDate + ";" + endDate + ";" + renewable + ";" + durationDays + ";" + appliedToLoyaltyCard;
    }

    public static Promotion fromLine(String line) {
        String[] parts = line.split(";");
        if (parts.length < 6) return null;
        if (parts.length < 11) {
            return new Promotion(parts[0], parts[1], PromotionType.valueOf(parts[2]), Double.parseDouble(parts[3]), Boolean.parseBoolean(parts[4]), parts[5]);
        }
        return new Promotion(parts[0], parts[1], PromotionType.valueOf(parts[2]), Double.parseDouble(parts[3]), 
                Boolean.parseBoolean(parts[4]), parts[5], LocalDate.parse(parts[6]), LocalDate.parse(parts[7]),
                Boolean.parseBoolean(parts[8]), Integer.parseInt(parts[9]), Boolean.parseBoolean(parts[10]));
    }
}
