package com.leadelmarche;

import com.leadelmarche.service.*;
import com.leadelmarche.view.MainWindow;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Path workspace = Paths.get(System.getProperty("user.home"), "LeadelMarche");
                DataStore dataStore = new DataStore(workspace);
                dataStore.initializeSampleData();

                // Services principaux
                InventoryService inventoryService = new InventoryService(dataStore);
                ClientService clientService = new ClientService(dataStore);
                PersonnelService personnelService = new PersonnelService(dataStore);
                PromotionService promotionService = new PromotionService(dataStore);
                SalesService salesService = new SalesService(dataStore, inventoryService, clientService, personnelService, promotionService);
                StatisticsService statisticsService = new StatisticsService(dataStore, salesService, inventoryService, clientService, personnelService);

                // Nouveaux services
                BarcodeService barcodeService = new BarcodeService(inventoryService);
                FastCheckoutService fastCheckoutService = new FastCheckoutService(barcodeService, inventoryService);
                ScheduleService scheduleService = new ScheduleService(dataStore, personnelService);
                StockAlertService stockAlertService = new StockAlertService(inventoryService);
                StoreService storeService = new StoreService(dataStore);
                ReportService reportService = new ReportService(salesService, inventoryService, clientService, personnelService);
                EmailService emailService = new EmailService("smtp.gmail.com", 587, "admin@leadelmarche.com", "password");

                MainWindow mainWindow = new MainWindow(inventoryService, clientService, personnelService, salesService, promotionService, statisticsService);
                mainWindow.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
