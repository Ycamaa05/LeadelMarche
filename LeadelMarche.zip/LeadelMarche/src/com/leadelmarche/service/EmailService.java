package com.leadelmarche.service;

import java.util.Properties;

public class EmailService {
    private String smtpServer;
    private int smtpPort;
    private String senderEmail;
    private String senderPassword;

    public EmailService(String smtpServer, int smtpPort, String senderEmail, String senderPassword) {
        this.smtpServer = smtpServer;
        this.smtpPort = smtpPort;
        this.senderEmail = senderEmail;
        this.senderPassword = senderPassword;
    }

    public boolean sendReport(String recipientEmail, String subject, String reportContent) {
        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", smtpServer);
            props.put("mail.smtp.port", smtpPort);
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");

            System.out.println("📧 Email envoyé à: " + recipientEmail);
            System.out.println("Sujet: " + subject);
            System.out.println("Contenu: " + reportContent.substring(0, Math.min(100, reportContent.length())));
            
            return true;
        } catch (Exception e) {
            System.err.println("Erreur lors de l'envoi de l'email: " + e.getMessage());
            return false;
        }
    }

    public boolean sendStatisticsReport(String recipientEmail, String statisticsName, String reportContent) {
        return sendReport(recipientEmail, "Rapport Statistiques - " + statisticsName, reportContent);
    }

    public boolean sendAlertEmail(String recipientEmail, String alertType, String message) {
        return sendReport(recipientEmail, "ALERTE - " + alertType, message);
    }
}
