package com.leadelmarche.service;

import com.leadelmarche.model.Product;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class BarcodeService {
    private final InventoryService inventoryService;

    public BarcodeService(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    public Optional<Product> findByBarcode(String barcode) {
        return inventoryService.getActiveProducts().stream()
                .filter(p -> p.getBarcode() != null && p.getBarcode().equals(barcode))
                .findFirst();
    }

    public List<Product> findByBarcodePattern(String pattern) {
        return inventoryService.getActiveProducts().stream()
                .filter(p -> p.getBarcode() != null && p.getBarcode().contains(pattern))
                .collect(Collectors.toList());
    }

    public boolean validateBarcode(String barcode) {
        if (barcode == null || barcode.isEmpty()) {
            return false;
        }
        return barcode.matches("\\d{8,14}");
    }

    public boolean isValidEAN13(String barcode) {
        if (barcode == null || barcode.length() != 13 || !barcode.matches("\\d+")) {
            return false;
        }
        int sum = 0;
        for (int i = 0; i < 12; i++) {
            int digit = Character.getNumericValue(barcode.charAt(i));
            if (i % 2 == 0) {
                sum += digit;
            } else {
                sum += digit * 3;
            }
        }
        int checkDigit = (10 - (sum % 10)) % 10;
        return checkDigit == Character.getNumericValue(barcode.charAt(12));
    }

    public Optional<Product> scanProduct(String barcode) {
        if (!validateBarcode(barcode)) {
            return Optional.empty();
        }
        return findByBarcode(barcode);
    }

    public List<Product> getProductsWithoutBarcode() {
        return inventoryService.getActiveProducts().stream()
                .filter(p -> p.getBarcode() == null || p.getBarcode().isEmpty())
                .collect(Collectors.toList());
    }

    public List<Product> getFoodProductsWithoutBarcode() {
        return inventoryService.getActiveProducts().stream()
                .filter(p -> p.getType() == Product.ProductType.ALIMENTS)
                .filter(p -> p.getBarcode() == null || p.getBarcode().isEmpty())
                .collect(Collectors.toList());
    }
}
