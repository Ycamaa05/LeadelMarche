package com.leadelmarche.service;

import com.leadelmarche.model.Promotion;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class PromotionService {
    private final DataStore store;
    private final List<Promotion> promotions;

    public PromotionService(DataStore store) throws IOException {
        this.store = store;
        this.promotions = new ArrayList<>(store.loadPromotions());
    }

    public List<Promotion> getActivePromotions() {
        return promotions.stream().filter(Promotion::isActive).sorted(Comparator.comparing(Promotion::getName)).collect(Collectors.toList());
    }

    public Optional<Promotion> findById(String id) {
        return promotions.stream().filter(p -> p.getId().equals(id)).findFirst();
    }

    public void addPromotion(Promotion promotion) throws IOException {
        promotions.add(promotion);
        persist();
    }

    public void updatePromotion(Promotion updated) throws IOException {
        findById(updated.getId()).ifPresent(promotion -> {
            promotion.setName(updated.getName());
            promotion.setType(updated.getType());
            promotion.setValue(updated.getValue());
            promotion.setDescription(updated.getDescription());
            promotion.setActive(updated.isActive());
        });
        persist();
    }

    public void deactivatePromotion(String id) throws IOException {
        findById(id).ifPresent(promotion -> promotion.setActive(false));
        persist();
    }

    public void persist() throws IOException {
        store.savePromotions(promotions);
    }
}
