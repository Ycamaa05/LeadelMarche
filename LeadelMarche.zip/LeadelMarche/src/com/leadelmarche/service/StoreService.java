package com.leadelmarche.service;

import com.leadelmarche.model.StoreLocation;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StoreService {
    private final DataStore store;
    private final List<StoreLocation> locations;

    public StoreService(DataStore store) throws IOException {
        this.store = store;
        this.locations = new ArrayList<>();
    }

    public void addLocation(StoreLocation location) throws IOException {
        locations.add(location);
        persist();
    }

    public Optional<StoreLocation> findById(String id) {
        return locations.stream().filter(l -> l.getId().equals(id)).findFirst();
    }

    public Optional<StoreLocation> findNearest(String city) {
        return locations.stream()
                .filter(StoreLocation::isActive)
                .filter(l -> l.getCity().equalsIgnoreCase(city))
                .findFirst();
    }

    public List<StoreLocation> getActiveLocations() {
        return new ArrayList<>(locations.stream()
                .filter(StoreLocation::isActive)
                .toList());
    }

    public List<StoreLocation> searchByCity(String city) {
        return locations.stream()
                .filter(l -> l.getCity().toLowerCase().contains(city.toLowerCase()))
                .toList();
    }

    public void updateLocation(StoreLocation updated) throws IOException {
        findById(updated.getId()).ifPresent(location -> {
            location.setCity(updated.getCity());
            location.setAddress(updated.getAddress());
            location.setPhone(updated.getPhone());
            location.setManager(updated.getManager());
            location.setActive(updated.isActive());
        });
        persist();
    }

    public void persist() throws IOException {
    }
}
