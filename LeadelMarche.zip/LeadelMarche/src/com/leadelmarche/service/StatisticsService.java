package com.leadelmarche.service;

import com.leadelmarche.model.Sale;
import com.leadelmarche.model.Statistic;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatisticsService {
    private final DataStore store;
    private final SalesService salesService;
    private final InventoryService inventoryService;
    private final ClientService clientService;
    private final PersonnelService personnelService;
    private final List<Statistic> customStatistics;

    public StatisticsService(DataStore store, SalesService salesService, InventoryService inventoryService, ClientService clientService, PersonnelService personnelService) {
        this.store = store;
        this.salesService = salesService;
        this.inventoryService = inventoryService;
        this.clientService = clientService;
        this.personnelService = personnelService;
        this.customStatistics = new ArrayList<>();
    }

    public long loyaltyCardsCreated(LocalDateTime from, LocalDateTime to) {
        return clientService.getActiveClients().stream()
                .filter(c -> c.getLoyaltyCardNumber() != null && !c.getLoyaltyCardNumber().isBlank())
                .count();
    }

    public long productsSoldForPromotion(String promotionName, LocalDateTime from, LocalDateTime to) {
        return salesService.getSalesInPeriod(from, to).stream().flatMap(s -> s.getItems().stream())
                .count();
    }

    public long absencesCount(LocalDateTime from, LocalDateTime to) {
        return personnelService.getActiveEmployees().stream().filter(e -> e.getWeeklyHours() < 35).count();
    }

    public String compareStatistic(String label, LocalDateTime aFrom, LocalDateTime aTo, LocalDateTime bFrom, LocalDateTime bTo) {
        long first = 0;
        long second = 0;
        if (label.contains("fidélité")) {
            first = loyaltyCardsCreated(aFrom, aTo);
            second = loyaltyCardsCreated(bFrom, bTo);
        } else if (label.contains("promotion")) {
            first = productsSoldForPromotion(label, aFrom, aTo);
            second = productsSoldForPromotion(label, bFrom, bTo);
        } else if (label.contains("absence")) {
            first = absencesCount(aFrom, aTo);
            second = absencesCount(bFrom, bTo);
        }
        return String.format("Période A: %d, Période B: %d", first, second);
    }

    public List<String> listAvailableStatistics() {
        return List.of(
                "Nombre de cartes de fidélité créées",
                "Nombre de produits vendus pour une promotion",
                "Nombre d'absences du personnel"
        );
    }

    public void addCustomStatistic(Statistic stat) {
        customStatistics.add(stat);
    }

    public List<Statistic> getCustomStatistics() {
        return new ArrayList<>(customStatistics);
    }

    public Map<String, Double> getStatisticData(String statisticName, LocalDateTime from, LocalDateTime to) {
        Map<String, Double> data = new HashMap<>();
        
        if (statisticName.contains("fidélité")) {
            data.put("Cartes créées", (double) loyaltyCardsCreated(from, to));
        } else if (statisticName.contains("produits vendus")) {
            data.put("Produits", (double) productsSoldForPromotion(statisticName, from, to));
        } else if (statisticName.contains("absence")) {
            data.put("Absences", (double) absencesCount(from, to));
        }

        return data;
    }

    public double getRevenueForPeriod(LocalDateTime from, LocalDateTime to) {
        return salesService.getSalesInPeriod(from, to).stream()
                .mapToDouble(Sale::getTotal)
                .sum();
    }

    public long getTotalProductsSold(LocalDateTime from, LocalDateTime to) {
        return salesService.getSalesInPeriod(from, to).stream()
                .flatMap(s -> s.getItems().stream())
                .count();
    }

    public Map<String, Long> getProductsSoldByPromotion(LocalDateTime from, LocalDateTime to) {
        Map<String, Long> result = new HashMap<>();
        salesService.getSalesInPeriod(from, to).forEach(sale -> {
            result.put("Ventes", result.getOrDefault("Ventes", 0L) + sale.getItems().size());
        });
        return result;
    }

    public List<String> getExpandedStatisticsList() {
        List<String> list = new ArrayList<>(listAvailableStatistics());
        customStatistics.forEach(s -> list.add(s.getName()));
        return list;
    }
}
