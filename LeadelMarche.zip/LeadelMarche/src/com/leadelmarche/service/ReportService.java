package com.leadelmarche.service;

import java.time.LocalDateTime;
import java.util.Map;

public class ReportService {
    private final SalesService salesService;
    private final InventoryService inventoryService;
    private final ClientService clientService;
    private final PersonnelService personnelService;

    public ReportService(SalesService salesService, InventoryService inventoryService, 
                        ClientService clientService, PersonnelService personnelService) {
        this.salesService = salesService;
        this.inventoryService = inventoryService;
        this.clientService = clientService;
        this.personnelService = personnelService;
    }

    public String generateRevenuReport(LocalDateTime from, LocalDateTime to) {
        double totalRevenue = salesService.getSalesInPeriod(from, to).stream()
                .mapToDouble(s -> s.getTotal())
                .sum();

        StringBuilder report = new StringBuilder();
        report.append("===== RAPPORT DE REVENU =====\n");
        report.append("Période: ").append(from).append(" au ").append(to).append("\n");
        report.append("Revenu total: ").append(String.format("%.2f€\n", totalRevenue));
        report.append("Nombre de transactions: ").append(salesService.getSalesInPeriod(from, to).size()).append("\n");

        return report.toString();
    }

    public String generateInventoryReport() {
        double totalValue = inventoryService.getActiveProducts().stream()
                .mapToDouble(p -> p.getStockQuantity() * p.getUnitPrice())
                .sum();

        StringBuilder report = new StringBuilder();
        report.append("===== RAPPORT D'INVENTAIRE =====\n");
        report.append("Nombre de produits: ").append(inventoryService.getActiveProducts().size()).append("\n");
        report.append("Valeur totale du stock: ").append(String.format("%.2f€\n", totalValue));

        return report.toString();
    }

    public String generateCustomStatisticReport(String statisticName, LocalDateTime from, LocalDateTime to) {
        StringBuilder report = new StringBuilder();
        report.append("===== RAPPORT STATISTIQUE PERSONNALISÉE =====\n");
        report.append("Statistique: ").append(statisticName).append("\n");
        report.append("Période: ").append(from).append(" au ").append(to).append("\n");

        return report.toString();
    }

    public byte[] generateChartData(String chartType, Map<String, Double> data) {
        switch (chartType.toLowerCase()) {
            case "pie":
            case "camembert":
                return generatePieChartData(data);
            case "bar":
            case "barre":
                return generateBarChartData(data);
            case "line":
            case "courbe":
                return generateLineChartData(data);
            default:
                return new byte[0];
        }
    }

    private byte[] generatePieChartData(Map<String, Double> data) {
        return String.format("PieChart: %s", data).getBytes();
    }

    private byte[] generateBarChartData(Map<String, Double> data) {
        return String.format("BarChart: %s", data).getBytes();
    }

    private byte[] generateLineChartData(Map<String, Double> data) {
        return String.format("LineChart: %s", data).getBytes();
    }

    public String exportReportAsHtml(String reportContent) {
        return "<html><body><pre>" + reportContent + "</pre></body></html>";
    }
}
