package com.leadelmarche.service;

import com.leadelmarche.model.Employee;

import java.io.IOException;
import java.text.Normalizer;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class PersonnelService {
    private final DataStore store;
    private final List<Employee> employees;

    public PersonnelService(DataStore store) throws IOException {
        this.store = store;
        this.employees = new ArrayList<>(store.loadEmployees());
    }

    public List<Employee> getActiveEmployees() {
        return employees.stream().filter(Employee::isActive).sorted(Comparator.comparing(Employee::getLastName)).collect(Collectors.toList());
    }

    public Optional<Employee> findById(String id) {
        return employees.stream().filter(e -> e.getId().equals(id)).findFirst();
    }

    public Optional<Employee> findByBadge(String badge) {
        return employees.stream().filter(e -> e.getBadgeNumber().equals(badge) && e.isActive()).findFirst();
    }

    public List<Employee> search(String pattern) {
        String search = normalize(pattern);
        return employees.stream().filter(Employee::isActive)
                .filter(e -> normalize(e.getFirstName()).contains(search) || normalize(e.getLastName()).contains(search) || normalize(e.getPosition()).contains(search))
                .sorted(Comparator.comparing(Employee::getLastName)).collect(Collectors.toList());
    }

    public void addEmployee(Employee employee) throws IOException {
        employees.add(employee);
        persist();
    }

    public void updateEmployee(Employee updated) throws IOException {
        findById(updated.getId()).ifPresent(employee -> {
            employee.setFirstName(updated.getFirstName());
            employee.setLastName(updated.getLastName());
            employee.setPersonalAddress(updated.getPersonalAddress());
            employee.setWorkAddress(updated.getWorkAddress());
            employee.setPosition(updated.getPosition());
            employee.setImmediateSupervisor(updated.getImmediateSupervisor());
            employee.setBadgeNumber(updated.getBadgeNumber());
            employee.setWeeklyHours(updated.getWeeklyHours());
            employee.setActive(updated.isActive());
        });
        persist();
    }

    public void deactivateEmployee(String id) throws IOException {
        findById(id).ifPresent(employee -> employee.setActive(false));
        persist();
    }

    public String computeScheduleAlert(LocalDate targetDate) {
        DayOfWeek day = targetDate.getDayOfWeek();
        if (day == DayOfWeek.SUNDAY) {
            return "Le magasin est fermé le dimanche normal, mais ouvert lors des 2 premiers dimanches de soldes. Vérifiez les périodes de soldes.";
        }
        long available = getActiveEmployees().stream().filter(e -> e.getWeeklyHours() >= 7).count();
        if (available < 6) {
            return "Alerte: effectif insuffisant pour " + targetDate + ". Pensez à réserver des intérimaires.";
        }
        return "Effectif adapté pour " + targetDate + ".";
    }

    public void persist() throws IOException {
        store.saveEmployees(employees);
    }

    public static String normalize(String input) {
        if (input == null) return "";
        String normalized = Normalizer.normalize(input.toLowerCase(), Normalizer.Form.NFD);
        return normalized.replaceAll("\\p{M}", "");
    }
}
