package com.leadelmarche.service;

import com.leadelmarche.model.Client;
import com.leadelmarche.model.Employee;
import com.leadelmarche.model.Product;
import com.leadelmarche.model.Promotion;
import com.leadelmarche.model.Sale;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class DataStore {
    private final Path root;
    private final Path productsFile;
    private final Path clientsFile;
    private final Path employeesFile;
    private final Path salesFile;
    private final Path promotionsFile;
    private final Path invoicesFolder;

    public DataStore(Path root) throws IOException {
        this.root = root;
        if (!Files.exists(root)) {
            Files.createDirectories(root);
        }
        this.productsFile = root.resolve("products.txt");
        this.clientsFile = root.resolve("clients.txt");
        this.employeesFile = root.resolve("employees.txt");
        this.salesFile = root.resolve("sales.txt");
        this.promotionsFile = root.resolve("promotions.txt");
        this.invoicesFolder = root.resolve("invoices");
        if (!Files.exists(invoicesFolder)) {
            Files.createDirectories(invoicesFolder);
        }
        ensureFilesExist();
    }

    private void ensureFilesExist() throws IOException {
        if (!Files.exists(productsFile)) Files.createFile(productsFile);
        if (!Files.exists(clientsFile)) Files.createFile(clientsFile);
        if (!Files.exists(employeesFile)) Files.createFile(employeesFile);
        if (!Files.exists(salesFile)) Files.createFile(salesFile);
        if (!Files.exists(promotionsFile)) Files.createFile(promotionsFile);
    }

    public List<Product> loadProducts() throws IOException {
        return Files.readAllLines(productsFile, StandardCharsets.UTF_8).stream()
                .map(Product::fromLine)
                .filter(p -> p != null)
                .collect(Collectors.toList());
    }

    public List<Client> loadClients() throws IOException {
        return Files.readAllLines(clientsFile, StandardCharsets.UTF_8).stream()
                .map(Client::fromLine)
                .filter(c -> c != null)
                .collect(Collectors.toList());
    }

    public List<Employee> loadEmployees() throws IOException {
        return Files.readAllLines(employeesFile, StandardCharsets.UTF_8).stream()
                .map(Employee::fromLine)
                .filter(e -> e != null)
                .collect(Collectors.toList());
    }

    public List<Sale> loadSales() throws IOException {
        return Files.readAllLines(salesFile, StandardCharsets.UTF_8).stream()
                .map(Sale::fromLine)
                .filter(s -> s != null)
                .collect(Collectors.toList());
    }

    public List<Promotion> loadPromotions() throws IOException {
        return Files.readAllLines(promotionsFile, StandardCharsets.UTF_8).stream()
                .map(Promotion::fromLine)
                .filter(p -> p != null)
                .collect(Collectors.toList());
    }

    public void saveProducts(List<Product> products) throws IOException {
        Files.write(productsFile, toLines(products), StandardCharsets.UTF_8);
    }

    public void saveClients(List<Client> clients) throws IOException {
        Files.write(clientsFile, toLines(clients), StandardCharsets.UTF_8);
    }

    public void saveEmployees(List<Employee> employees) throws IOException {
        Files.write(employeesFile, toLines(employees), StandardCharsets.UTF_8);
    }

    public void saveSales(List<Sale> sales) throws IOException {
        Files.write(salesFile, toLines(sales), StandardCharsets.UTF_8);
    }

    public void savePromotions(List<Promotion> promotions) throws IOException {
        Files.write(promotionsFile, toLines(promotions), StandardCharsets.UTF_8);
    }

    public void saveInvoice(String invoiceName, String content) throws IOException {
        Path invoiceFile = invoicesFolder.resolve(invoiceName);
        Files.write(invoiceFile, content.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    public Path getInvoiceFolder() {
        return invoicesFolder;
    }

    public String nextId() {
        return UUID.randomUUID().toString();
    }

    private <T> List<String> toLines(List<T> items) {
        List<String> lines = new ArrayList<>();
        for (T item : items) {
            lines.add(item.toString());
        }
        return lines;
    }

    public void initializeSampleData() throws IOException {
        if (Files.size(productsFile) == 0 && Files.size(clientsFile) == 0 && Files.size(employeesFile) == 0 && Files.size(promotionsFile) == 0) {
            List<Product> sampleProducts = new ArrayList<>();
            sampleProducts.add(new Product(nextId(), "Avocat", "Avocat frais", Product.ProductType.ALIMENTS, 1.95, "Espagne", 5.5, 120, "FruitsPlus", "0001112223334", true, true));
            sampleProducts.add(new Product(nextId(), "Kiwi", "Kiwi vert par pièce", Product.ProductType.ALIMENTS, 0.55, "France", 5.5, 250, "GreenFarm", "0001112223335", false, true));
            sampleProducts.add(new Product(nextId(), "Pain complet", "Pain de campagne 500g", Product.ProductType.ALIMENTS, 2.80, "France", 5.5, 80, "Boulangerie", "9780201379624", false, true));
            sampleProducts.add(new Product(nextId(), "Aspirine", "Aspirine 20 comprimés", Product.ProductType.MEDECINES, 4.20, "France", 20, 40, "PharmaPlus", "0001112223336", false, true));
            sampleProducts.add(new Product(nextId(), "Smartphone Basic", "Téléphone 4G entrée de gamme", Product.ProductType.ELECTRONIQUE, 129.99, "Chine", 20, 15, "TechPro", "0001112223337", false, true));
            sampleProducts.add(new Product(nextId(), "Chargeur USB", "Chargeur rapide USB-C", Product.ProductType.ELECTRONIQUE, 14.90, "Chine", 20, 55, "TechPro", "0001112223338", false, true));
            sampleProducts.add(new Product(nextId(), "Souris sans fil", "Souris optique Bluetooth", Product.ProductType.ELECTRONIQUE, 22.50, "Chine", 20, 28, "TechPro", "0001112223339", false, true));
            sampleProducts.add(new Product(nextId(), "Gel douche", "Gel douche relaxant 250ml", Product.ProductType.AUTRES, 3.10, "France", 20, 65, "CosmiRelax", "0001112223340", false, true));
            sampleProducts.add(new Product(nextId(), "Lessive liquide", "Lessive éco 2L", Product.ProductType.AUTRES, 9.50, "France", 20, 45, "CleanCare", "0001112223341", false, true));
            sampleProducts.add(new Product(nextId(), "Pile AA", "Pack 4 piles AA", Product.ProductType.AUTRES, 5.90, "Allemagne", 20, 120, "PowerCell", "0001112223342", false, true));
            saveProducts(sampleProducts);

            List<Client> sampleClients = new ArrayList<>();
            sampleClients.add(new Client(nextId(), "Anonyme", "Client", "0000000000", "", "00000", true));
            sampleClients.add(new Client(nextId(), "Emma", "Dupont", "FID1001", "emma.dupont@example.com", "75001", true));
            sampleClients.add(new Client(nextId(), "Emmanuel", "Rossi", "FID1002", "emmanuel.rossi@example.com", "69002", true));
            sampleClients.add(new Client(nextId(), "Émilie", "Martin", "FID1003", "emilie.martin@example.com", "13003", true));
            sampleClients.add(new Client(nextId(), "Luc", "Leblanc", "FID1004", "luc.leblanc@example.com", "06000", true));
            sampleClients.add(new Client(nextId(), "Sarah", "Nguyen", "FID1005", "sarah.nguyen@example.com", "75002", true));
            sampleClients.add(new Client(nextId(), "Nicolas", "Moreau", "FID1006", "nicolas.moreau@example.com", "33000", true));
            sampleClients.add(new Client(nextId(), "Julie", "Simon", "FID1007", "julie.simon@example.com", "17000", true));
            sampleClients.add(new Client(nextId(), "Antoine", "Leroy", "FID1008", "antoine.leroy@example.com", "44000", true));
            sampleClients.add(new Client(nextId(), "Chloé", "Dubois", "FID1009", "chloe.dubois@example.com", "21000", true));
            saveClients(sampleClients);

            List<Employee> sampleEmployees = new ArrayList<>();
            sampleEmployees.add(new Employee(nextId(), "Alice", "Bernard", "12 rue des Fleurs", "LeadelMarché Centre", "Caissière", "Paul Martin", "B1001", 35, true));
            sampleEmployees.add(new Employee(nextId(), "Marc", "Lemoine", "3 avenue Victor Hugo", "LeadelMarché Centre", "Chef de Rayon", "Paul Martin", "B1002", 35, true));
            sampleEmployees.add(new Employee(nextId(), "Paul", "Martin", "18 rue de Paris", "LeadelMarché Centre", "Directeur", "N/A", "B1003", 35, true));
            sampleEmployees.add(new Employee(nextId(), "Sophie", "Durand", "4 place du Marché", "LeadelMarché Sud", "Caissière", "Marc Lemoine", "B1004", 25, true));
            sampleEmployees.add(new Employee(nextId(), "Hugo", "Petit", "5 rue du Stade", "LeadelMarché Sud", "Adjoint de rayon", "Paul Martin", "B1005", 30, true));
            sampleEmployees.add(new Employee(nextId(), "Emma", "Roux", "9 boulevard Victor", "LeadelMarché Nord", "Caissière", "Sophie Durand", "B1006", 21, true));
            sampleEmployees.add(new Employee(nextId(), "Théo", "Vincent", "2 rue de la Gare", "LeadelMarché Nord", "Intérimaire", "Marc Lemoine", "B1007", 15, true));
            sampleEmployees.add(new Employee(nextId(), "Nina", "Richard", "11 rue des Oliviers", "LeadelMarché Centre", "HR", "Paul Martin", "B1008", 35, true));
            sampleEmployees.add(new Employee(nextId(), "Pierre", "Faure", "20 route de Lyon", "LeadelMarché Sud", "Caissier", "Sophie Durand", "B1009", 35, true));
            sampleEmployees.add(new Employee(nextId(), "Camille", "Gauthier", "7 rue du Lac", "LeadelMarché Centre", "Caissière", "Paul Martin", "B1010", 28, true));
            saveEmployees(sampleEmployees);

            List<Promotion> samplePromotions = new ArrayList<>();
            samplePromotions.add(new Promotion(nextId(), "2+1 gratuit", Promotion.PromotionType.DEUX_ACHETES_TROISIEME_OFFERT, 0, true, "Offre 2 achetés 3ème offert sur article identique."));
            samplePromotions.add(new Promotion(nextId(), "30% 2ème produit", Promotion.PromotionType.POURCENTAGE_SUR_DEUXIEME, 30, true, "30% sur le 2ème produit identique."));
            samplePromotions.add(new Promotion(nextId(), "Cagnotte fidélité", Promotion.PromotionType.CAGNOTTE_FIDELITE, 5, true, "5€ crédités sur la cagnotte fidélité pour achats supérieurs à 50€."));
            savePromotions(samplePromotions);
        }
    }
}
