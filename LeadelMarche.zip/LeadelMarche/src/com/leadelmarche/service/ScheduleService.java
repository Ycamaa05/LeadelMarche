package com.leadelmarche.service;

import com.leadelmarche.model.DayOff;
import com.leadelmarche.model.Employee;
import com.leadelmarche.model.EmployeeContract;
import com.leadelmarche.model.Shift;

import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ScheduleService {
    private final DataStore store;
    private final PersonnelService personnelService;
    private final List<Shift> shifts;
    private final List<DayOff> daysOff;
    private final List<EmployeeContract> contracts;

    public ScheduleService(DataStore store, PersonnelService personnelService) throws IOException {
        this.store = store;
        this.personnelService = personnelService;
        this.shifts = new ArrayList<>();
        this.daysOff = new ArrayList<>();
        this.contracts = new ArrayList<>();
    }

    public void addContract(EmployeeContract contract) throws IOException {
        contracts.add(contract);
        persist();
    }

    public void addDayOff(DayOff dayOff) throws IOException {
        daysOff.add(dayOff);
        persist();
    }

    public void addShift(Shift shift) throws IOException {
        shifts.add(shift);
        persist();
    }

    public List<DayOff> getEmployeeDaysOff(String employeeId) {
        return daysOff.stream()
                .filter(d -> d.getEmployeeId().equals(employeeId))
                .collect(Collectors.toList());
    }

    public List<Shift> getEmployeeShifts(String employeeId, LocalDate date) {
        return shifts.stream()
                .filter(s -> s.getEmployeeId().equals(employeeId) && s.getDate().equals(date))
                .collect(Collectors.toList());
    }

    public Optional<EmployeeContract> getActiveContract(String employeeId) {
        LocalDate today = LocalDate.now();
        return contracts.stream()
                .filter(c -> c.getEmployeeId().equals(employeeId) && c.isActive())
                .filter(c -> !c.getStartDate().isAfter(today))
                .filter(c -> c.getEndDate() == null || !c.getEndDate().isBefore(today))
                .findFirst();
    }

    public String generateOptimalSchedule(LocalDate from, LocalDate to) {
        StringBuilder schedule = new StringBuilder();
        schedule.append("===== PLANNING DU ").append(from).append(" AU ").append(to).append(" =====\n");

        for (LocalDate currentDate = from; !currentDate.isAfter(to); currentDate = currentDate.plusDays(1)) {
            DayOfWeek dayOfWeek = currentDate.getDayOfWeek();
            
            if (dayOfWeek == DayOfWeek.SUNDAY) {
                schedule.append(currentDate).append(" (DIMANCHE) - Magasin fermé (sauf soldes)\n");
                continue;
            }

            schedule.append(currentDate).append(" (").append(dayOfWeek).append(") - ");

            List<Employee> employees = personnelService.getActiveEmployees();
            final LocalDate finalDate = currentDate;
            List<Employee> availableEmployees = employees.stream()
                    .filter(e -> !isEmployeeOffOnDate(e.getId(), finalDate))
                    .collect(Collectors.toList());

            if (availableEmployees.size() < 6) {
                schedule.append("⚠️ EFFECTIF INSUFFISANT (").append(availableEmployees.size()).append(" employés)\n");
            } else {
                schedule.append("✓ Effectif OK (").append(availableEmployees.size()).append(" employés)\n");
            }
        }

        return schedule.toString();
    }

    private boolean isEmployeeOffOnDate(String employeeId, LocalDate date) {
        return daysOff.stream()
                .filter(d -> d.getEmployeeId().equals(employeeId))
                .anyMatch(d -> !date.isBefore(d.getStartDate()) && !date.isAfter(d.getEndDate()));
    }

    public int calculateBreaks(int hoursWorked) {
        if (hoursWorked >= 7) {
            return 1 + (hoursWorked >= 7 ? 2 : 0);
        }
        return 1;
    }

    public Shift createOptimalShift(String employeeId, LocalDate date, int hoursRequested) {
        int fifteenMinBreaks = 0;
        boolean lunchBreak = false;

        if (hoursRequested >= 7) {
            lunchBreak = true;
            fifteenMinBreaks = 2;
        } else if (hoursRequested > 0) {
            fifteenMinBreaks = 1;
        }

        LocalTime startTime = LocalTime.of(8, 0);
        LocalTime endTime = startTime.plusHours(hoursRequested);

        return new Shift(store.nextId(), employeeId, date, startTime, endTime, hoursRequested, lunchBreak, fifteenMinBreaks);
    }

    public double calculateWeeklyCost(String employeeId, LocalDate weekStart) {
        double totalCost = 0;
        Optional<EmployeeContract> contract = getActiveContract(employeeId);

        if (contract.isPresent()) {
            for (int i = 0; i < 6; i++) {
                LocalDate date = weekStart.plusDays(i);
                List<Shift> dayShifts = getEmployeeShifts(employeeId, date);
                double dailyCost = dayShifts.stream()
                        .mapToDouble(s -> s.getDurationHours() * contract.get().getHourlyRate())
                        .sum();
                totalCost += dailyCost;
            }
        }

        return totalCost;
    }

    public void persist() throws IOException {
    }
}
