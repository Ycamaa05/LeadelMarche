package com.leadelmarche.service;

import com.leadelmarche.model.Product;

import java.io.IOException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class InventoryService {
    private final DataStore store;
    private final List<Product> products;

    public InventoryService(DataStore store) throws IOException {
        this.store = store;
        this.products = new ArrayList<>(store.loadProducts());
    }

    public List<Product> getActiveProducts() {
        return products.stream().filter(Product::isActive).sorted(Comparator.comparing(Product::getName)).collect(Collectors.toList());
    }

    public Optional<Product> findById(String id) {
        return products.stream().filter(p -> p.getId().equals(id)).findFirst();
    }

    public Optional<Product> findByBarcode(String barcode) {
        return products.stream().filter(p -> barcode.equals(p.getBarcode()) && p.isActive()).findFirst();
    }

    public List<Product> search(String pattern) {
        String search = normalize(pattern);
        return products.stream().filter(Product::isActive)
                .filter(p -> normalize(p.getName()).contains(search) || normalize(p.getDescription()).contains(search) || normalize(p.getSupplierName()).contains(search))
                .sorted(Comparator.comparing(Product::getName)).collect(Collectors.toList());
    }

    public void addProduct(Product product) throws IOException {
        products.add(product);
        persist();
    }

    public void updateProduct(Product updated) throws IOException {
        findById(updated.getId()).ifPresent(product -> {
            product.setName(updated.getName());
            product.setDescription(updated.getDescription());
            product.setType(updated.getType());
            product.setUnitPrice(updated.getUnitPrice());
            product.setOriginCountry(updated.getOriginCountry());
            product.setTvaPercent(updated.getTvaPercent());
            product.setStockQuantity(updated.getStockQuantity());
            product.setSupplierName(updated.getSupplierName());
            product.setBarcode(updated.getBarcode());
            product.setSoldByWeight(updated.isSoldByWeight());
            product.setActive(updated.isActive());
        });
        persist();
    }

    public void deactivateProduct(String id) throws IOException {
        findById(id).ifPresent(product -> product.setActive(false));
        persist();
    }

    public void changeStock(String id, double quantity) throws IOException {
        findById(id).ifPresent(product -> product.setStockQuantity(product.getStockQuantity() + quantity));
        persist();
    }

    public List<Product> getLowStock(double thresholdPercent) {
        return products.stream().filter(Product::isActive)
                .filter(p -> p.getStockQuantity() <= thresholdPercent)
                .sorted(Comparator.comparing(Product::getStockQuantity))
                .collect(Collectors.toList());
    }

    public void persist() throws IOException {
        store.saveProducts(products);
    }

    public static String normalize(String input) {
        if (input == null) return "";
        String normalized = Normalizer.normalize(input.toLowerCase(), Normalizer.Form.NFD);
        return normalized.replaceAll("\\p{M}", "");
    }
}
