package com.leadelmarche.service;

import com.leadelmarche.model.Product;
import java.util.List;
import java.util.stream.Collectors;

public class StockAlertService {
    private final InventoryService inventoryService;
    private final double alertThreshold;

    public StockAlertService(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
        this.alertThreshold = 0.20;
    }

    public StockAlertService(InventoryService inventoryService, double alertThresholdPercent) {
        this.inventoryService = inventoryService;
        this.alertThreshold = alertThresholdPercent / 100.0;
    }

    public List<Product> getProductsWithLowStock() {
        return inventoryService.getActiveProducts().stream()
                .filter(this::isStockLow)
                .collect(Collectors.toList());
    }

    public boolean isStockLow(Product product) {
        if (product == null || !product.isActive()) {
            return false;
        }
        return product.getStockQuantity() <= (product.getStockQuantity() * alertThreshold);
    }

    public String generateStockAlertReport() {
        List<Product> lowStockProducts = getProductsWithLowStock();

        if (lowStockProducts.isEmpty()) {
            return "Tous les stocks sont bons.\n";
        }

        StringBuilder report = new StringBuilder();
        report.append("===== ALERTE STOCK BAS =====\n");
        report.append("Produits avec stock inférieur à ").append((int)(alertThreshold * 100)).append("%\n\n");

        for (Product product : lowStockProducts) {
            report.append("- ").append(product.getName()).append("\n");
            report.append("  Stock actuel: ").append(product.getStockQuantity()).append("\n");
            report.append("  Fournisseur: ").append(product.getSupplierName()).append("\n");
            report.append("  Suggérer réapprovisionnement\n\n");
        }

        return report.toString();
    }

    public void checkAndAlertLowStock() {
        List<Product> lowStockProducts = getProductsWithLowStock();
        if (!lowStockProducts.isEmpty()) {
            System.out.println("⚠️ ALERTE: " + lowStockProducts.size() + " produits ont un stock faible!");
        }
    }
}
