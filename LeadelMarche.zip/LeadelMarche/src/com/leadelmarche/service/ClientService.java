package com.leadelmarche.service;

import com.leadelmarche.model.Client;

import java.io.IOException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ClientService {
    private final DataStore store;
    private final List<Client> clients;

    public ClientService(DataStore store) throws IOException {
        this.store = store;
        this.clients = new ArrayList<>(store.loadClients());
        ensureAnonymousClient();
    }

    public List<Client> getActiveClients() {
        return clients.stream().filter(Client::isActive).sorted(Comparator.comparing(Client::getLastName)).collect(Collectors.toList());
    }

    public Optional<Client> findById(String id) {
        return clients.stream().filter(c -> c.getId().equals(id)).findFirst();
    }

    public Optional<Client> findByLoyaltyCard(String cardNumber) {
        return clients.stream().filter(c -> c.getLoyaltyCardNumber().equals(cardNumber) && c.isActive()).findFirst();
    }

    public List<Client> search(String pattern) {
        String search = normalize(pattern);
        return clients.stream().filter(Client::isActive)
                .filter(c -> normalize(c.getFirstName()).contains(search) || normalize(c.getLastName()).contains(search) || normalize(c.getEmail()).contains(search))
                .sorted(Comparator.comparing(Client::getLastName)).collect(Collectors.toList());
    }

    public void addClient(Client client) throws IOException {
        clients.add(client);
        persist();
    }

    public void updateClient(Client updated) throws IOException {
        findById(updated.getId()).ifPresent(client -> {
            client.setFirstName(updated.getFirstName());
            client.setLastName(updated.getLastName());
            client.setLoyaltyCardNumber(updated.getLoyaltyCardNumber());
            client.setEmail(updated.getEmail());
            client.setPostalCode(updated.getPostalCode());
            client.setActive(updated.isActive());
        });
        persist();
    }

    public void deactivateClient(String id) throws IOException {
        findById(id).ifPresent(client -> client.setActive(false));
        persist();
    }

    private void ensureAnonymousClient() throws IOException {
        if (clients.stream().noneMatch(c -> "Anonyme".equalsIgnoreCase(c.getFirstName()) && c.isActive())) {
            clients.add(new Client(store.nextId(), "Anonyme", "Client", "0000000000", "", "00000", true));
            persist();
        }
    }

    public void persist() throws IOException {
        store.saveClients(clients);
    }

    public static String normalize(String input) {
        if (input == null) return "";
        String normalized = Normalizer.normalize(input.toLowerCase(), Normalizer.Form.NFD);
        return normalized.replaceAll("\\p{M}", "");
    }
}
