package com.leadelmarche.service;

import com.leadelmarche.model.Product;
import com.leadelmarche.model.SaleItem;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class FastCheckoutService {
    private final BarcodeService barcodeService;
    private final InventoryService inventoryService;
    private List<SaleItem> currentItems;
    private boolean blockStatus;

    public FastCheckoutService(BarcodeService barcodeService, InventoryService inventoryService) {
        this.barcodeService = barcodeService;
        this.inventoryService = inventoryService;
        this.currentItems = new ArrayList<>();
        this.blockStatus = false;
    }

    public void startSession() {
        currentItems.clear();
        blockStatus = false;
    }

    public boolean scanProductWithBalance(String barcode, double weightMeasured) {
        Optional<Product> product = barcodeService.scanProduct(barcode);
        if (product.isEmpty()) {
            blockStatus = true;
            return false;
        }

        Product p = product.get();
        if (!p.isRequiresBalanceValidation()) {
            addScannedProduct(p);
            return true;
        }

        double expectedWeight = p.getExpectedWeight();
        double tolerance = p.getWeightTolerance();
        double minWeight = expectedWeight * (1 - tolerance);
        double maxWeight = expectedWeight * (1 + tolerance);

        if (weightMeasured >= minWeight && weightMeasured <= maxWeight) {
            addScannedProduct(p);
            return true;
        } else {
            blockStatus = true;
            return false;
        }
    }

    public void addScannedProduct(Product product) {
        Optional<SaleItem> existing = currentItems.stream()
                .filter(item -> item.getProductId().equals(product.getId()))
                .findFirst();

        if (existing.isPresent()) {
            SaleItem item = existing.get();
            item.setQuantity(item.getQuantity() + 1);
        } else {
            String itemId = UUID.randomUUID().toString();
            SaleItem item = new SaleItem(itemId, product.getId(), product.getName(),
                    1, product.getUnitPrice(), product.isSoldByWeight());
            currentItems.add(item);
        }
    }

    public void manuallySelectProduct(String productId, int quantity) {
        Optional<Product> product = inventoryService.findById(productId);
        if (product.isPresent()) {
            Product p = product.get();
            String itemId = UUID.randomUUID().toString();
            SaleItem item = new SaleItem(itemId, p.getId(), p.getName(),
                    quantity, p.getUnitPrice(), p.isSoldByWeight());
            currentItems.add(item);
        }
    }

    public void callCashier() {
        blockStatus = false;
    }

    public boolean isBlocked() {
        return blockStatus;
    }

    public void removeItem(String itemId) {
        currentItems.removeIf(item -> item.getId().equals(itemId));
    }

    public List<SaleItem> getCurrentItems() {
        return new ArrayList<>(currentItems);
    }

    public double getTotalAmount() {
        return currentItems.stream().mapToDouble(SaleItem::getTotalPrice).sum();
    }

    public void clearSession() {
        startSession();
    }
}
