package com.leadelmarche.service;

import com.leadelmarche.model.Client;
import com.leadelmarche.model.Employee;
import com.leadelmarche.model.Product;
import com.leadelmarche.model.Promotion;
import com.leadelmarche.model.Sale;
import com.leadelmarche.model.SaleItem;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class SalesService {
    private final DataStore store;
    private final InventoryService inventoryService;
    private final ClientService clientService;
    private final PersonnelService personnelService;
    private final PromotionService promotionService;
    private final List<Sale> sales;

    public SalesService(DataStore store, InventoryService inventoryService, ClientService clientService,
                        PersonnelService personnelService, PromotionService promotionService) throws IOException {
        this.store = store;
        this.inventoryService = inventoryService;
        this.clientService = clientService;
        this.personnelService = personnelService;
        this.promotionService = promotionService;
        this.sales = new ArrayList<>(store.loadSales());
    }

    public List<Sale> getActiveSales() {
        return sales.stream().filter(Sale::isActive).sorted(Comparator.comparing(Sale::getDateTime).reversed()).collect(Collectors.toList());
    }

    public void recordSale(String storeName, String cashierBadge, String clientCardNumber, List<SaleItem> items) throws IOException {
        Optional<Employee> cashier = personnelService.findByBadge(cashierBadge);
        if (cashier.isEmpty()) {
            throw new IllegalArgumentException("Badge introuvable : " + cashierBadge);
        }

        Client client = clientService.findByLoyaltyCard(clientCardNumber).orElseGet(() ->
                clientService.getActiveClients().stream().filter(c -> "0000000000".equals(c.getLoyaltyCardNumber())).findFirst().orElse(null));

        double subtotal = 0;
        double tvaTotal = 0;
        for (SaleItem item : items) {
            Optional<Product> product = inventoryService.findById(item.getProductId());
            product.ifPresent(p -> {
                double currentStock = p.getStockQuantity();
                p.setStockQuantity(Math.max(0, currentStock - item.getQuantity()));
            });
            subtotal += item.getTotalPrice();
            tvaTotal += item.getTotalPrice() * 0.20;
        }

        Promotion promotion = promotionService.getActivePromotions().stream().findFirst().orElse(null);
        double discount = applyPromotions(items, promotion);

        double total = subtotal + tvaTotal - discount;
        Sale sale = new Sale(store.nextId(), storeName, cashierBadge, client != null ? client.getLoyaltyCardNumber() : "0000000000",
                items, subtotal, tvaTotal, total, LocalDateTime.now(), true);
        sales.add(sale);
        store.saveSales(sales);
        inventoryService.persist();
        if (client != null) clientService.persist();
        String invoice = buildInvoice(sale, promotion, discount, client, cashier.get());
        store.saveInvoice("ticket_" + sale.getId() + ".txt", invoice);
    }

    private double applyPromotions(List<SaleItem> items, Promotion promotion) {
        if (promotion == null) return 0;
        double discount = 0;
        if (promotion.getType() == Promotion.PromotionType.POURCENTAGE_SUR_DEUXIEME) {
            for (SaleItem item : items) {
                if (item.getQuantity() >= 2) {
                    discount += item.getUnitPrice() * (promotion.getValue() / 100.0);
                }
            }
        } else if (promotion.getType() == Promotion.PromotionType.DEUX_ACHETES_TROISIEME_OFFERT) {
            for (SaleItem item : items) {
                if (item.getQuantity() >= 3) {
                    discount += item.getUnitPrice();
                }
            }
        } else if (promotion.getType() == Promotion.PromotionType.CAGNOTTE_FIDELITE) {
            discount += promotion.getValue();
        }
        return discount;
    }

    private String buildInvoice(Sale sale, Promotion promotion, double discount, Client client, Employee cashier) {
        StringBuilder builder = new StringBuilder();
        builder.append("LeadelMarché - Ticket de caisse\n");
        builder.append("Date : ").append(sale.getDateTimeString()).append("\n");
        builder.append("Point de vente : ").append(sale.getStoreName()).append("\n");
        builder.append("Caissier : ").append(cashier.getFirstName()).append(" ").append(cashier.getLastName()).append(" (Badge ").append(cashier.getBadgeNumber()).append(")\n");
        builder.append("Client : ").append(client != null ? client.getFirstName() + " " + client.getLastName() : "Anonyme").append("\n");
        builder.append("-------------------------------------------------\n");
        for (SaleItem item : sale.getItems()) {
            builder.append(item.getProductName()).append(" x ").append(item.getQuantity()).append(" @ ").append(String.format("%.2f", item.getUnitPrice())).append(" = ")
                    .append(String.format("%.2f", item.getTotalPrice())).append("\n");
        }
        builder.append("-------------------------------------------------\n");
        builder.append("Sous-total : ").append(String.format("%.2f", sale.getSubtotal())).append("€\n");
        builder.append("TVA : ").append(String.format("%.2f", sale.getTvaAmount())).append("€\n");
        if (promotion != null && discount > 0) {
            builder.append("Promotion : ").append(promotion.getName()).append(" (-").append(String.format("%.2f", discount)).append("€)\n");
        }
        builder.append("Total à payer : ").append(String.format("%.2f", sale.getTotal())).append("€\n");
        builder.append("Merci de votre visite !\n");
        return builder.toString();
    }

    public List<Sale> searchSalesByStore(String storePattern) {
        String pattern = storePattern.toLowerCase();
        return sales.stream().filter(Sale::isActive).filter(s -> s.getStoreName().toLowerCase().contains(pattern)).collect(Collectors.toList());
    }

    public List<Sale> getSalesInPeriod(LocalDateTime from, LocalDateTime to) {
        return sales.stream().filter(Sale::isActive).filter(s -> !s.getDateTime().isBefore(from) && !s.getDateTime().isAfter(to)).collect(Collectors.toList());
    }
}
