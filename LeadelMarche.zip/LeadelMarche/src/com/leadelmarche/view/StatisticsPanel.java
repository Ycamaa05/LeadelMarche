package com.leadelmarche.view;

import com.leadelmarche.service.ClientService;
import com.leadelmarche.service.PersonnelService;
import com.leadelmarche.service.SalesService;
import com.leadelmarche.service.StatisticsService;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.time.LocalDateTime;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class StatisticsPanel extends JPanel {
    private final StatisticsService statisticsService;
    private final ClientService clientService;
    private final SalesService salesService;
    private final PersonnelService personnelService;
    private final JComboBox<String> statCombo;
    private final JTextField fromField;
    private final JTextField toField;
    private final JTextField compareFromField;
    private final JTextField compareToField;
    private final JTextArea resultArea;
    private final DefaultTableModel historyModel;
    private final JTable historyTable;

    public StatisticsPanel(StatisticsService statisticsService, ClientService clientService, SalesService salesService, PersonnelService personnelService) {
        this.statisticsService = statisticsService;
        this.clientService = clientService;
        this.salesService = salesService;
        this.personnelService = personnelService;
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 245, 245));

        JPanel form = new JPanel(new GridLayout(5, 2, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Paramètres de Statistiques"));
        form.setBackground(Color.WHITE);
        statCombo = new JComboBox<>();
        for (String stat : statisticsService.listAvailableStatistics()) {
            statCombo.addItem(stat);
        }
        statCombo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        fromField = new JTextField(LocalDateTime.now().minusMonths(1).toLocalDate().toString());
        fromField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        toField = new JTextField(LocalDateTime.now().toLocalDate().toString());
        toField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        compareFromField = new JTextField(LocalDateTime.now().minusYears(1).toLocalDate().toString());
        compareFromField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        compareToField = new JTextField(LocalDateTime.now().minusMonths(11).toLocalDate().toString());
        compareToField.setFont(new Font("SansSerif", Font.PLAIN, 12));

        form.add(new JLabel("📊 Statistique :")); form.add(statCombo);
        form.add(new JLabel("📅 Période A début :")); form.add(fromField);
        form.add(new JLabel("📅 Période A fin :")); form.add(toField);
        form.add(new JLabel("📅 Période B début :")); form.add(compareFromField);
        form.add(new JLabel("📅 Période B fin :")); form.add(compareToField);
        add(form, BorderLayout.NORTH);

        JPanel buttons = new JPanel(new GridLayout(1, 3, 10, 10));
        buttons.setBorder(new EmptyBorder(10, 0, 10, 0));
        JButton computeButton = new JButton("🔍 Calculer");
        computeButton.setToolTipText("Calculer la statistique pour la période A (Ctrl+C)");
        computeButton.setMnemonic('C');
        computeButton.setBackground(new Color(70, 130, 180));
        computeButton.setForeground(Color.WHITE);
        computeButton.setFocusPainted(false);
        JButton compareButton = new JButton("⚖️ Comparer");
        compareButton.setToolTipText("Comparer les périodes A et B (Ctrl+P)");
        compareButton.setMnemonic('P');
        compareButton.setBackground(new Color(255, 165, 0));
        compareButton.setForeground(Color.WHITE);
        compareButton.setFocusPainted(false);
        JButton addButton = new JButton("➕ Ajouter Stat");
        addButton.setToolTipText("Ajouter une nouvelle statistique personnalisée (Ctrl+A)");
        addButton.setMnemonic('A');
        addButton.setBackground(new Color(34, 139, 34));
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        buttons.add(computeButton);
        buttons.add(compareButton);
        buttons.add(addButton);
        add(buttons, BorderLayout.CENTER);

        resultArea = new JTextArea(8, 20);
        resultArea.setEditable(false);
        resultArea.setFont(new Font("SansSerif", Font.PLAIN, 12));
        resultArea.setBackground(Color.WHITE);
        add(new JScrollPane(resultArea), BorderLayout.SOUTH);

        historyModel = new DefaultTableModel(new Object[]{"Type", "Période", "Valeur"}, 0);
        historyTable = new JTable(historyModel);
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(historyModel);
        historyTable.setRowSorter(sorter);
        historyTable.setFont(new Font("SansSerif", Font.PLAIN, 12));
        historyTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        add(new JScrollPane(historyTable), BorderLayout.EAST);

        computeButton.addActionListener(e -> computeStat());
        compareButton.addActionListener(e -> compareStat());
        addButton.addActionListener(e -> addCustomStat());
    }

    private void computeStat() {
        try {
            String label = statCombo.getSelectedItem().toString();
            LocalDateTime from = LocalDateTime.parse(fromField.getText() + "T00:00:00");
            LocalDateTime to = LocalDateTime.parse(toField.getText() + "T23:59:59");
            long value = 0;
            if (label.contains("fidélité")) {
                value = statisticsService.loyaltyCardsCreated(from, to);
            } else if (label.contains("produits vendus")) {
                value = statisticsService.productsSoldForPromotion(label, from, to);
            } else if (label.contains("absences")) {
                value = statisticsService.absencesCount(from, to);
            }
            String output = String.format("%s\nPériode : %s à %s\nValeur : %d", label, fromField.getText(), toField.getText(), value);
            resultArea.setText(output);
            historyModel.addRow(new Object[]{label, fromField.getText() + " / " + toField.getText(), value});
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur de calcul : " + e.getMessage());
        }
    }

    private void compareStat() {
        try {
            String label = statCombo.getSelectedItem().toString();
            LocalDateTime aFrom = LocalDateTime.parse(fromField.getText() + "T00:00:00");
            LocalDateTime aTo = LocalDateTime.parse(toField.getText() + "T23:59:59");
            LocalDateTime bFrom = LocalDateTime.parse(compareFromField.getText() + "T00:00:00");
            LocalDateTime bTo = LocalDateTime.parse(compareToField.getText() + "T23:59:59");
            String summary = statisticsService.compareStatistic(label, aFrom, aTo, bFrom, bTo);
            resultArea.setText("Comparaison de \"" + label + "\"\n" + summary);
            historyModel.addRow(new Object[]{label + " (comparaison)", compareFromField.getText() + " / " + compareToField.getText(), summary});
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur de comparaison : " + e.getMessage());
        }
    }

    private void addCustomStat() {
        String custom = JOptionPane.showInputDialog(this, "Nom de la nouvelle statistique :");
        if (custom == null || custom.isBlank()) return;
        statCombo.addItem(custom);
        JOptionPane.showMessageDialog(this, "Statistique ajoutée : " + custom);
    }
}
