package com.leadelmarche.view;

import com.leadelmarche.model.Employee;
import com.leadelmarche.service.PersonnelService;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.time.LocalDate;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class PersonnelPanel extends JPanel {
    private final PersonnelService personnelService;
    private final DefaultTableModel tableModel;
    private final JTable table;
    private final JTextField searchField;

    public PersonnelPanel(PersonnelService personnelService) {
        this.personnelService = personnelService;
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 245, 245));

        JPanel top = new JPanel(new BorderLayout(6, 6));
        top.setBorder(BorderFactory.createTitledBorder("Recherche d'Employés"));
        top.setBackground(Color.WHITE);
        searchField = new JTextField();
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        top.add(new JLabel("🔍 Recherche employé :"), BorderLayout.WEST);
        top.add(searchField, BorderLayout.CENTER);
        JButton searchButton = new JButton("Chercher");
        searchButton.setBackground(new Color(70, 130, 180));
        searchButton.setForeground(Color.WHITE);
        searchButton.setFocusPainted(false);
        top.add(searchButton, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"ID", "Prénom", "Nom", "Travail", "Badge", "Heures/semaine", "Active"}, 0);
        table = new JTable(tableModel);
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        table.setFont(new Font("SansSerif", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel buttons = new JPanel(new GridLayout(1, 4, 10, 10));
        buttons.setBorder(new EmptyBorder(10, 0, 0, 0));
        JButton createButton = new JButton("➕ Ajouter");
        createButton.setToolTipText("Ajouter un nouvel employé (Ctrl+N)");
        createButton.setMnemonic('N');
        createButton.setBackground(new Color(34, 139, 34));
        createButton.setForeground(Color.WHITE);
        createButton.setFocusPainted(false);
        JButton editButton = new JButton("✏️ Modifier");
        editButton.setToolTipText("Modifier l'employé sélectionné (Ctrl+E)");
        editButton.setMnemonic('E');
        editButton.setBackground(new Color(255, 165, 0));
        editButton.setForeground(Color.WHITE);
        editButton.setFocusPainted(false);
        JButton deleteButton = new JButton("❌ Désactiver");
        deleteButton.setToolTipText("Désactiver l'employé sélectionné (Ctrl+D)");
        deleteButton.setMnemonic('D');
        deleteButton.setBackground(new Color(220, 20, 60));
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setFocusPainted(false);
        JButton alertButton = new JButton("🚨 Alerte Planning");
        alertButton.setToolTipText("Vérifier les alertes de planning (Ctrl+A)");
        alertButton.setMnemonic('A');
        alertButton.setBackground(new Color(255, 69, 0));
        alertButton.setForeground(Color.WHITE);
        alertButton.setFocusPainted(false);
        buttons.add(createButton);
        buttons.add(editButton);
        buttons.add(deleteButton);
        buttons.add(alertButton);
        add(buttons, BorderLayout.SOUTH);

        searchButton.addActionListener(e -> loadEmployees(searchField.getText()));
        createButton.addActionListener(e -> openEditor(null));
        editButton.addActionListener(e -> editSelectedEmployee());
        deleteButton.addActionListener(e -> deactivateSelectedEmployee());
        alertButton.addActionListener(e -> showScheduleAlert());

        loadEmployees("");
    }

    private void loadEmployees(String search) {
        try {
            List<Employee> list = search.isBlank() ? personnelService.getActiveEmployees() : personnelService.search(search);
            tableModel.setRowCount(0);
            for (Employee employee : list) {
                tableModel.addRow(new Object[]{employee.getId(), employee.getFirstName(), employee.getLastName(), employee.getPosition(), employee.getBadgeNumber(), employee.getWeeklyHours(), employee.isActive()});
            }
        } catch (Exception e) {
            showError(e);
        }
    }

    private void openEditor(Employee existing) {
        try {
            EmployeeEditor editor = new EmployeeEditor(existing);
            int result = JOptionPane.showConfirmDialog(this, editor.getPanel(), existing == null ? "Ajouter employé" : "Modifier employé", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result == JOptionPane.OK_OPTION) {
                Employee employee = editor.buildEmployee();
                if (existing == null) {
                    personnelService.addEmployee(employee);
                } else {
                    personnelService.updateEmployee(employee);
                }
                loadEmployees("");
            }
        } catch (Exception e) {
            showError(e);
        }
    }

    private void editSelectedEmployee() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un employé.");
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        personnelService.findById(id).ifPresent(this::openEditor);
    }

    private void deactivateSelectedEmployee() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un employé à désactiver.", "Aucune sélection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        String firstName = (String) tableModel.getValueAt(row, 1);
        String lastName = (String) tableModel.getValueAt(row, 2);

        int confirm = JOptionPane.showConfirmDialog(this,
            "Êtes-vous sûr de vouloir désactiver l'employé :\n" + firstName + " " + lastName + " (ID: " + id + ") ?",
            "Confirmation de désactivation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                personnelService.deactivateEmployee(id);
                loadEmployees("");
                JOptionPane.showMessageDialog(this, "Employé désactivé avec succès.", "Succès", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                showError(e);
            }
        }
    }

    private void showScheduleAlert() {
        String dateText = JOptionPane.showInputDialog(this, "Date pour alerte (YYYY-MM-DD) :", LocalDate.now().toString());
        if (dateText == null) return;
        try {
            LocalDate date = LocalDate.parse(dateText);
            String alert = personnelService.computeScheduleAlert(date);
            JOptionPane.showMessageDialog(this, alert);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Date invalide. Utilisez le format YYYY-MM-DD.");
        }
    }

    private void showError(Exception e) {
        JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
    }

    private class EmployeeEditor {
        private final JPanel panel;
        private final JTextField firstNameField;
        private final JTextField lastNameField;
        private final JTextField personalAddressField;
        private final JTextField workAddressField;
        private final JTextField positionField;
        private final JTextField supervisorField;
        private final JTextField badgeField;
        private final JTextField hoursField;

        EmployeeEditor(Employee existing) {
            panel = new JPanel(new GridLayout(9, 2, 4, 4));
            firstNameField = new JTextField();
            lastNameField = new JTextField();
            personalAddressField = new JTextField();
            workAddressField = new JTextField();
            positionField = new JTextField();
            supervisorField = new JTextField();
            badgeField = new JTextField();
            hoursField = new JTextField();

            panel.add(new JLabel("Prénom :")); panel.add(firstNameField);
            panel.add(new JLabel("Nom :")); panel.add(lastNameField);
            panel.add(new JLabel("Adresse personnelle :")); panel.add(personalAddressField);
            panel.add(new JLabel("Adresse lieu de travail :")); panel.add(workAddressField);
            panel.add(new JLabel("Poste :")); panel.add(positionField);
            panel.add(new JLabel("Supérieur :")); panel.add(supervisorField);
            panel.add(new JLabel("Numéro badge :")); panel.add(badgeField);
            panel.add(new JLabel("Heures / semaine :")); panel.add(hoursField);

            if (existing != null) {
                firstNameField.setText(existing.getFirstName());
                lastNameField.setText(existing.getLastName());
                personalAddressField.setText(existing.getPersonalAddress());
                workAddressField.setText(existing.getWorkAddress());
                positionField.setText(existing.getPosition());
                supervisorField.setText(existing.getImmediateSupervisor());
                badgeField.setText(existing.getBadgeNumber());
                hoursField.setText(String.valueOf(existing.getWeeklyHours()));
            }
        }

        JPanel getPanel() {
            return panel;
        }

        Employee buildEmployee() {
            String id = (table.getSelectedRow() >= 0) ? (String) tableModel.getValueAt(table.getSelectedRow(), 0) : java.util.UUID.randomUUID().toString();
            return new Employee(id, firstNameField.getText(), lastNameField.getText(), personalAddressField.getText(),
                    workAddressField.getText(), positionField.getText(), supervisorField.getText(), badgeField.getText(),
                    Integer.parseInt(hoursField.getText()), true);
        }
    }
}
