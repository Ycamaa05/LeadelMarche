package com.leadelmarche.view;

import com.leadelmarche.service.PersonnelService;
import com.leadelmarche.service.ScheduleService;
import java.awt.*;
import java.time.LocalDate;
import javax.swing.*;

public class SchedulePanel extends JPanel {
    private ScheduleService scheduleService;
    private PersonnelService personnelService;

    private JTextArea scheduleArea;
    private JTextField fromDateField;
    private JTextField toDateField;

    public SchedulePanel(ScheduleService scheduleService, PersonnelService personnelService) {
        this.scheduleService = scheduleService;
        this.personnelService = personnelService;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createTitledBorder("Gestion des Horaires et Emploi du Temps"));

        add(createControlPanel(), BorderLayout.NORTH);
        add(createDisplayPanel(), BorderLayout.CENTER);
        add(createActionPanel(), BorderLayout.SOUTH);
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 4, 5, 5));
        panel.setBorder(BorderFactory.createTitledBorder("Paramètres"));

        panel.add(new JLabel("Du (yyyy-MM-dd):"));
        fromDateField = new JTextField(LocalDate.now().toString());
        panel.add(fromDateField);

        panel.add(new JLabel("Au (yyyy-MM-dd):"));
        toDateField = new JTextField(LocalDate.now().plusDays(7).toString());
        panel.add(toDateField);

        JButton generateButton = new JButton("Générer planning");
        generateButton.addActionListener(e -> generateSchedule());
        panel.add(generateButton);

        JButton addContractButton = new JButton("Ajouter contrat");
        addContractButton.addActionListener(e -> addContract());
        panel.add(addContractButton);

        JButton addDayOffButton = new JButton("Ajouter congé");
        addDayOffButton.addActionListener(e -> addDayOff());
        panel.add(addDayOffButton);

        JButton alertButton = new JButton("Vérifier effectif");
        alertButton.addActionListener(e -> checkStaffing());
        panel.add(alertButton);

        return panel;
    }

    private JPanel createDisplayPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        scheduleArea = new JTextArea();
        scheduleArea.setEditable(false);
        scheduleArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        panel.add(new JScrollPane(scheduleArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createActionPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        JButton exportButton = new JButton("Exporter");
        exportButton.addActionListener(e -> exportSchedule());
        panel.add(exportButton);

        return panel;
    }

    private void generateSchedule() {
        try {
            LocalDate from = LocalDate.parse(fromDateField.getText());
            LocalDate to = LocalDate.parse(toDateField.getText());
            
            String schedule = scheduleService.generateOptimalSchedule(from, to);
            scheduleArea.setText(schedule);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Format de date invalide (yyyy-MM-dd)");
        }
    }

    private void addContract() {
        String employeeId = JOptionPane.showInputDialog(this, "ID Employé:");
        if (employeeId == null) return;

        String[] contractTypes = {"CDI", "CDI_STUDENT", "CDD", "INTERIM"};
        String typeStr = (String) JOptionPane.showInputDialog(this, "Type de contrat:", "Contrat", 
                JOptionPane.QUESTION_MESSAGE, null, contractTypes, contractTypes[0]);
        if (typeStr == null) return;

        String hoursStr = JOptionPane.showInputDialog(this, "Heures/semaine:");
        try {
            int hours = Integer.parseInt(hoursStr);
            JOptionPane.showMessageDialog(this, "Contrat ajouté pour " + employeeId);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Heures invalides");
        }
    }

    private void addDayOff() {
        String employeeId = JOptionPane.showInputDialog(this, "ID Employé:");
        if (employeeId == null) return;

        String[] dayOffTypes = {"CONGE", "RTT", "MALADIE", "AUTRE"};
        String typeStr = (String) JOptionPane.showInputDialog(this, "Type d'absence:", "Absence", 
                JOptionPane.QUESTION_MESSAGE, null, dayOffTypes, dayOffTypes[0]);
        if (typeStr == null) return;

        JOptionPane.showMessageDialog(this, "Absence enregistrée pour " + employeeId);
    }

    private void checkStaffing() {
        StringBuilder msg = new StringBuilder("Vérification d'effectif:\n\n");
        
        long activeEmployees = personnelService.getActiveEmployees().size();
        msg.append("Employés actifs: ").append(activeEmployees).append("\n");
        msg.append("Minimum requis: 6\n");

        if (activeEmployees < 6) {
            msg.append("\n⚠️ ALERTE: Effectif insuffisant!\n");
            msg.append("Ressources intérimaires recommandées");
        } else {
            msg.append("\n✓ Effectif adapté");
        }

        scheduleArea.setText(msg.toString());
    }

    private void exportSchedule() {
        JOptionPane.showMessageDialog(this, "Planning exporté");
    }
}
