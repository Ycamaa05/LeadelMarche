package com.leadelmarche.view;

import com.leadelmarche.model.Product;
import com.leadelmarche.model.SaleItem;
import com.leadelmarche.service.ClientService;
import com.leadelmarche.service.InventoryService;
import com.leadelmarche.service.PersonnelService;
import com.leadelmarche.service.SalesService;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class SalesPanel extends JPanel {
    private final SalesService salesService;
    private final InventoryService inventoryService;
    private final ClientService clientService;
    private final PersonnelService personnelService;
    private final DefaultTableModel cartModel;
    private final JTable cartTable;
    private final JComboBox<String> productCombo;
    private final JTextField barcodeField;
    private final JTextField quantityField;
    private final JTextField storeField;
    private final JTextField cashierField;
    private final JTextField clientField;
    private final JLabel totalLabel;
    private final List<SaleItem> cartItems = new ArrayList<>();

    public SalesPanel(SalesService salesService, InventoryService inventoryService, ClientService clientService, PersonnelService personnelService) {
        this.salesService = salesService;
        this.inventoryService = inventoryService;
        this.clientService = clientService;
        this.personnelService = personnelService;
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 245, 245));

        JPanel top = new JPanel(new GridLayout(2, 4, 8, 8));
        top.setBorder(BorderFactory.createTitledBorder("Informations de Vente"));
        top.setBackground(Color.WHITE);
        storeField = new JTextField("LeadelMarché Centre");
        storeField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        cashierField = new JTextField();
        cashierField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        clientField = new JTextField("0000000000");
        clientField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        top.add(new JLabel("🏪 Point de vente :")); top.add(storeField);
        top.add(new JLabel("👷 Badge caissier :")); top.add(cashierField);
        top.add(new JLabel("👤 Carte fidélité client :")); top.add(clientField);
        add(top, BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(8, 8));
        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Ajouter au Panier"));
        form.setBackground(Color.WHITE);
        productCombo = new JComboBox<>();
        productCombo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        barcodeField = new JTextField();
        barcodeField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        quantityField = new JTextField("1");
        quantityField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        JButton addButton = new JButton("➕ Ajouter au Panier");
        addButton.setToolTipText("Ajouter l'article au panier (Ctrl+A)");
        addButton.setMnemonic('A');
        addButton.setBackground(new Color(34, 139, 34));
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        form.add(new JLabel("📦 Produit (sélection) :")); form.add(productCombo);
        form.add(new JLabel("📱 Code-barres (scan) :")); form.add(barcodeField);
        form.add(new JLabel("🔢 Quantité / poids :")); form.add(quantityField);
        form.add(new JLabel()); form.add(addButton);
        center.add(form, BorderLayout.NORTH);

        cartModel = new DefaultTableModel(new Object[]{"Produit", "Qté", "Prix unitaire", "Total", "Poids"}, 0);
        cartTable = new JTable(cartModel);
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(cartModel);
        cartTable.setRowSorter(sorter);
        cartTable.setFont(new Font("SansSerif", Font.PLAIN, 12));
        cartTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        center.add(new JScrollPane(cartTable), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new GridLayout(1, 3, 10, 10));
        bottom.setBorder(new EmptyBorder(10, 0, 0, 0));
        JButton removeButton = new JButton("➖ Retirer Article");
        removeButton.setToolTipText("Retirer l'article sélectionné du panier (Ctrl+R)");
        removeButton.setMnemonic('R');
        removeButton.setBackground(new Color(255, 165, 0));
        removeButton.setForeground(Color.WHITE);
        removeButton.setFocusPainted(false);
        JButton sellButton = new JButton("💰 Enregistrer Vente");
        sellButton.setToolTipText("Finaliser et enregistrer la vente (Ctrl+Enter)");
        sellButton.setMnemonic('V');
        sellButton.setBackground(new Color(0, 128, 0));
        sellButton.setForeground(Color.WHITE);
        sellButton.setFocusPainted(false);
        totalLabel = new JLabel("💵 Total : 0.00 €", SwingConstants.CENTER);
        totalLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        totalLabel.setForeground(new Color(0, 100, 0));
        bottom.add(removeButton);
        bottom.add(totalLabel);
        bottom.add(sellButton);
        add(bottom, BorderLayout.SOUTH);

        addButton.addActionListener(e -> addItem());
        removeButton.addActionListener(e -> removeItem());
        sellButton.addActionListener(e -> completeSale());

        refreshProductList();
    }

    private void refreshProductList() {
        productCombo.removeAllItems();
        for (Product product : inventoryService.getActiveProducts()) {
            productCombo.addItem(product.getId() + " - " + product.getName());
        }
    }

    private void addItem() {
        try {
            Product product = null;
            if (!barcodeField.getText().isBlank()) {
                product = inventoryService.findByBarcode(barcodeField.getText()).orElse(null);
                if (product == null) {
                    JOptionPane.showMessageDialog(this, "Produit introuvable par code-barres.");
                    return;
                }
            }
            if (product == null && productCombo.getSelectedItem() != null) {
                String value = productCombo.getSelectedItem().toString();
                String id = value.split(" - ")[0];
                product = inventoryService.findById(id).orElse(null);
            }
            if (product == null) {
                JOptionPane.showMessageDialog(this, "Veuillez sélectionner un produit ou scanner un code-barres.");
                return;
            }
            double quantity = Double.parseDouble(quantityField.getText().replace(',', '.'));
            if (quantity <= 0) {
                JOptionPane.showMessageDialog(this, "Quantité invalide.");
                return;
            }
            SaleItem item = new SaleItem(product.getId(), product.getName(), quantity, product.getUnitPrice(), product.isSoldByWeight());
            cartItems.add(item);
            cartModel.addRow(new Object[]{item.getProductName(), item.getQuantity(), item.getUnitPrice(), item.getTotalPrice(), item.isSoldByWeight()});
            updateTotal();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Entrez une quantité valide.");
        }
    }

    private void removeItem() {
        int row = cartTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un article à retirer.");
            return;
        }
        cartItems.remove(row);
        cartModel.removeRow(row);
        updateTotal();
    }

    private void completeSale() {
        if (cartItems.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Le panier est vide.");
            return;
        }
        try {
            salesService.recordSale(storeField.getText(), cashierField.getText(), clientField.getText(), cartItems);
            JOptionPane.showMessageDialog(this, "Vente enregistrée et ticket généré.");
            cartItems.clear();
            cartModel.setRowCount(0);
            updateTotal();
            refreshProductList();
        } catch (IOException e) {
            showError(e);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Impossible de finaliser la vente : " + e.getMessage());
        }
    }

    private void updateTotal() {
        double total = cartItems.stream().mapToDouble(SaleItem::getTotalPrice).sum();
        totalLabel.setText(String.format("Total : %.2f €", total));
    }

    private void showError(Exception e) {
        JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
    }
}
