package com.leadelmarche.view;

import com.leadelmarche.service.EmailService;
import com.leadelmarche.service.ReportService;
import com.leadelmarche.service.StatisticsService;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;

public class AdvancedStatisticsPanel extends JPanel {
    private StatisticsService statisticsService;
    private ReportService reportService;
    private EmailService emailService;

    private JComboBox<String> statisticCombo;
    private JTextArea reportArea;
    private JTextField fromDateField;
    private JTextField toDateField;

    public AdvancedStatisticsPanel(StatisticsService statisticsService, ReportService reportService, EmailService emailService) {
        this.statisticsService = statisticsService;
        this.reportService = reportService;
        this.emailService = emailService;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createTitledBorder("Statistiques Avancées"));

        add(createControlPanel(), BorderLayout.NORTH);
        add(createReportPanel(), BorderLayout.CENTER);
        add(createActionPanel(), BorderLayout.SOUTH);
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 6, 5, 5));
        panel.setBorder(BorderFactory.createTitledBorder("Paramètres"));

        panel.add(new JLabel("Statistique:"));
        statisticCombo = new JComboBox<>(statisticsService.getExpandedStatisticsList().toArray(new String[0]));
        panel.add(statisticCombo);

        panel.add(new JLabel("Du (yyyy-MM-dd):"));
        LocalDate thirtyDaysAgo = LocalDate.now().minusDays(30);
        fromDateField = new JTextField(thirtyDaysAgo.toString());
        panel.add(fromDateField);

        panel.add(new JLabel("Au (yyyy-MM-dd):"));
        toDateField = new JTextField(LocalDate.now().toString());
        panel.add(toDateField);

        JButton generateButton = new JButton("Générer");
        generateButton.addActionListener(e -> generateReport());
        panel.add(generateButton);

        JButton customButton = new JButton("+ Stat personnalisée");
        customButton.addActionListener(e -> addCustomStatistic());
        panel.add(customButton);

        return panel;
    }

    private JPanel createReportPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        reportArea = new JTextArea();
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        panel.add(new JScrollPane(reportArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createActionPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));

        String[] chartTypes = {"Tableau", "Camembert", "Barres", "Courbe"};
        JComboBox<String> chartCombo = new JComboBox<>(chartTypes);
        panel.add(new JLabel("Format:"));
        panel.add(chartCombo);

        JButton chartButton = new JButton("Afficher graphique");
        chartButton.addActionListener(e -> showChart(chartCombo.getSelectedItem().toString()));
        panel.add(chartButton);

        JButton emailButton = new JButton("Envoyer par email");
        emailButton.addActionListener(e -> sendByEmail());
        panel.add(emailButton);

        JButton compareButton = new JButton("Comparer périodes");
        compareButton.addActionListener(e -> comparePeriods());
        panel.add(compareButton);

        return panel;
    }

    private void generateReport() {
        try {
            String statisticName = (String) statisticCombo.getSelectedItem();
            LocalDate fromDate = LocalDate.parse(fromDateField.getText());
            LocalDate toDate = LocalDate.parse(toDateField.getText());
            LocalDateTime from = fromDate.atStartOfDay();
            LocalDateTime to = toDate.atTime(LocalTime.MAX);

            StringBuilder report = new StringBuilder();
            report.append("===== RAPPORT STATISTIQUE =====\n");
            report.append("Statistique: ").append(statisticName).append("\n");
            report.append("Période: ").append(fromDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
                  .append(" au ").append(toDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))).append("\n\n");

            var data = statisticsService.getStatisticData(statisticName, from, to);
            
            data.forEach((key, value) -> {
                report.append(key).append(": ").append(String.format("%.2f", value)).append("\n");
            });

            reportArea.setText(report.toString());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur: " + ex.getMessage());
        }
    }

    private void addCustomStatistic() {
        String name = JOptionPane.showInputDialog(this, "Nom de la statistique:");
        if (name == null || name.isEmpty()) return;

        String description = JOptionPane.showInputDialog(this, "Description:");
        if (description == null) description = "";

        JOptionPane.showMessageDialog(this, "Statistique personnalisée '" + name + "' ajoutée!");
    }

    private void showChart(String chartType) {
        StringBuilder msg = new StringBuilder();
        msg.append("Graphique ").append(chartType).append(" généré\n\n");
        msg.append("Contenu du graphique basé sur les données du rapport");
        
        JOptionPane.showMessageDialog(this, msg.toString(), "Graphique", JOptionPane.INFORMATION_MESSAGE);
    }

    private void sendByEmail() {
        String email = JOptionPane.showInputDialog(this, "Adresse email du destinataire:");
        if (email == null || email.isEmpty()) return;

        String subject = "Rapport Statistique - " + statisticsService.listAvailableStatistics().get(0);
        boolean sent = emailService.sendStatisticsReport(email, subject, reportArea.getText());

        if (sent) {
            JOptionPane.showMessageDialog(this, "Email envoyé avec succès à " + email);
        } else {
            JOptionPane.showMessageDialog(this, "Erreur lors de l'envoi de l'email", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void comparePeriods() {
        try {
            LocalDate aFromDate = LocalDate.parse(fromDateField.getText());
            LocalDate aToDate = LocalDate.parse(toDateField.getText());
            LocalDateTime aFrom = aFromDate.atStartOfDay();
            LocalDateTime aTo = aToDate.atTime(LocalTime.MAX);
            
            LocalDateTime bFrom = aFrom.minusYears(1);
            LocalDateTime bTo = aTo.minusYears(1);

            String statisticName = (String) statisticCombo.getSelectedItem();
            
            StringBuilder comparison = new StringBuilder();
            comparison.append("===== COMPARAISON DE PÉRIODES =====\n\n");
            comparison.append("Année A (").append(aFrom.getYear()).append("): ");
            comparison.append(aFrom.format(DateTimeFormatter.ofPattern("dd/MM")))
                     .append(" au ").append(aTo.format(DateTimeFormatter.ofPattern("dd/MM"))).append("\n");
            comparison.append("Année B (").append(bFrom.getYear()).append("): ");
            comparison.append(bFrom.format(DateTimeFormatter.ofPattern("dd/MM")))
                     .append(" au ").append(bTo.format(DateTimeFormatter.ofPattern("dd/MM"))).append("\n\n");

            comparison.append(statisticsService.compareStatistic(statisticName, aFrom, aTo, bFrom, bTo));

            reportArea.setText(comparison.toString());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur: " + ex.getMessage());
        }
    }
}
