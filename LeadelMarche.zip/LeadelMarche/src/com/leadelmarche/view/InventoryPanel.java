package com.leadelmarche.view;

import com.leadelmarche.model.Product;
import com.leadelmarche.service.InventoryService;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class InventoryPanel extends JPanel {
    private final InventoryService inventoryService;
    private final DefaultTableModel tableModel;
    private final JTable table;
    private final JTextField searchField;

    public InventoryPanel(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 245, 245));

        JPanel top = new JPanel(new BorderLayout(6, 6));
        top.setBorder(BorderFactory.createTitledBorder("Recherche de Produits"));
        top.setBackground(Color.WHITE);
        searchField = new JTextField();
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        top.add(new JLabel("🔍 Recherche produit :"), BorderLayout.WEST);
        top.add(searchField, BorderLayout.CENTER);
        JButton searchButton = new JButton("Chercher");
        searchButton.setBackground(new Color(70, 130, 180));
        searchButton.setForeground(Color.WHITE);
        searchButton.setFocusPainted(false);
        top.add(searchButton, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"ID", "Nom", "Type", "Prix", "Stock", "Code-barres", "Poids", "Actif"}, 0);
        table = new JTable(tableModel);
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel buttons = new JPanel(new GridLayout(1, 4, 10, 10));
        buttons.setBorder(new EmptyBorder(10, 0, 0, 0));
        JButton createButton = new JButton("➕ Ajouter");
        createButton.setToolTipText("Ajouter un nouveau produit à l'inventaire (Ctrl+N)");
        createButton.setMnemonic('N');
        createButton.setBackground(new Color(34, 139, 34));
        createButton.setForeground(Color.WHITE);
        createButton.setFocusPainted(false);
        JButton editButton = new JButton("✏️ Modifier");
        editButton.setToolTipText("Modifier le produit sélectionné (Ctrl+E)");
        editButton.setMnemonic('E');
        editButton.setBackground(new Color(255, 165, 0));
        editButton.setForeground(Color.WHITE);
        editButton.setFocusPainted(false);
        JButton deleteButton = new JButton("❌ Désactiver");
        deleteButton.setToolTipText("Désactiver le produit sélectionné (Ctrl+D)");
        deleteButton.setMnemonic('D');
        deleteButton.setBackground(new Color(220, 20, 60));
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setFocusPainted(false);
        JButton restockButton = new JButton("📊 Modifier Stock");
        restockButton.setToolTipText("Ajuster la quantité en stock du produit sélectionné (Ctrl+S)");
        restockButton.setMnemonic('S');
        restockButton.setBackground(new Color(70, 130, 180));
        restockButton.setForeground(Color.WHITE);
        restockButton.setFocusPainted(false);
        buttons.add(createButton);
        buttons.add(editButton);
        buttons.add(deleteButton);
        buttons.add(restockButton);
        add(buttons, BorderLayout.SOUTH);

        searchButton.addActionListener(e -> loadProducts(searchField.getText()));
        createButton.addActionListener(e -> openEditor(null));
        editButton.addActionListener(e -> editSelectedProduct());
        deleteButton.addActionListener(e -> deactivateSelectedProduct());
        restockButton.addActionListener(e -> updateStock());

        loadProducts("");
    }

    private void loadProducts(String search) {
        try {
            List<Product> list = search.isBlank() ? inventoryService.getActiveProducts() : inventoryService.search(search);
            tableModel.setRowCount(0);
            for (Product product : list) {
                tableModel.addRow(new Object[]{product.getId(), product.getName(), product.getType(), product.getUnitPrice(), product.getStockQuantity(), product.getBarcode(), product.isSoldByWeight(), product.isActive()});
            }
        } catch (Exception e) {
            showError(e);
        }
    }

    private void openEditor(Product existing) {
        try {
            ProductEditor editor = new ProductEditor(existing);
            int result = JOptionPane.showConfirmDialog(this, editor.getPanel(), existing == null ? "Ajouter produit" : "Modifier produit", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result == JOptionPane.OK_OPTION) {
                Product product = editor.buildProduct();
                if (existing == null) {
                    inventoryService.addProduct(product);
                } else {
                    inventoryService.updateProduct(product);
                }
                loadProducts("");
            }
        } catch (Exception e) {
            showError(e);
        }
    }

    private void editSelectedProduct() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un produit.");
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        inventoryService.findById(id).ifPresent(this::openEditor);
    }

    private void deactivateSelectedProduct() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un produit à désactiver.", "Aucune sélection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        String name = (String) tableModel.getValueAt(row, 1);

        int confirm = JOptionPane.showConfirmDialog(this,
            "Êtes-vous sûr de vouloir désactiver le produit :\n" + name + " (ID: " + id + ") ?",
            "Confirmation de désactivation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                inventoryService.deactivateProduct(id);
                loadProducts("");
                JOptionPane.showMessageDialog(this, "Produit désactivé avec succès.", "Succès", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                showError(e);
            }
        }
    }

    private void updateStock() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un produit.");
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        String input = JOptionPane.showInputDialog(this, "Quantité à ajouter (ou soustraire) :", "0");
        if (input == null) return;
        try {
            double delta = Double.parseDouble(input);
            inventoryService.changeStock(id, delta);
            loadProducts("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Entrez un nombre valide.");
        } catch (Exception e) {
            showError(e);
        }
    }

    private void showError(Exception e) {
        JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
    }

    private class ProductEditor {
        private final JPanel panel;
        private final JTextField nameField;
        private final JTextField descriptionField;
        private final JComboBox<Product.ProductType> typeBox;
        private final JTextField priceField;
        private final JTextField countryField;
        private final JTextField tvaField;
        private final JTextField stockField;
        private final JTextField supplierField;
        private final JTextField barcodeField;
        private final JComboBox<String> weightBox;

        ProductEditor(Product existing) {
            panel = new JPanel(new GridLayout(10, 2, 4, 4));
            nameField = new JTextField();
            descriptionField = new JTextField();
            typeBox = new JComboBox<>(Product.ProductType.values());
            priceField = new JTextField();
            countryField = new JTextField();
            tvaField = new JTextField();
            stockField = new JTextField();
            supplierField = new JTextField();
            barcodeField = new JTextField();
            weightBox = new JComboBox<>(new String[]{"Oui", "Non"});

            panel.add(new JLabel("Nom :")); panel.add(nameField);
            panel.add(new JLabel("Description :")); panel.add(descriptionField);
            panel.add(new JLabel("Type :")); panel.add(typeBox);
            panel.add(new JLabel("Prix unitaire :")); panel.add(priceField);
            panel.add(new JLabel("Pays d'origine :")); panel.add(countryField);
            panel.add(new JLabel("TVA (%) :")); panel.add(tvaField);
            panel.add(new JLabel("Quantité en stock :")); panel.add(stockField);
            panel.add(new JLabel("Fournisseur :")); panel.add(supplierField);
            panel.add(new JLabel("Code-barres :")); panel.add(barcodeField);
            panel.add(new JLabel("Vend en poids :")); panel.add(weightBox);

            if (existing != null) {
                nameField.setText(existing.getName());
                descriptionField.setText(existing.getDescription());
                typeBox.setSelectedItem(existing.getType());
                priceField.setText(String.valueOf(existing.getUnitPrice()));
                countryField.setText(existing.getOriginCountry());
                tvaField.setText(String.valueOf(existing.getTvaPercent()));
                stockField.setText(String.valueOf(existing.getStockQuantity()));
                supplierField.setText(existing.getSupplierName());
                barcodeField.setText(existing.getBarcode());
                weightBox.setSelectedItem(existing.isSoldByWeight() ? "Oui" : "Non");
            }
        }

        JPanel getPanel() {
            return panel;
        }

        Product buildProduct() {
            String id = existingId();
            return new Product(id, nameField.getText(), descriptionField.getText(), (Product.ProductType) typeBox.getSelectedItem(),
                    Double.parseDouble(priceField.getText()), countryField.getText(), Double.parseDouble(tvaField.getText()),
                    Double.parseDouble(stockField.getText()), supplierField.getText(), barcodeField.getText(),
                    "Oui".equals(weightBox.getSelectedItem()), true);
        }

        private String existingId() {
            int row = table.getSelectedRow();
            if (row >= 0) {
                return (String) tableModel.getValueAt(row, 0);
            }
            return java.util.UUID.randomUUID().toString();
        }
    }
}
