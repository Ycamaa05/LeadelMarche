package com.leadelmarche.view;

import com.leadelmarche.service.BarcodeService;
import com.leadelmarche.service.FastCheckoutService;
import java.awt.*;
import javax.swing.*;

public class FastCheckoutPanel extends JPanel {
    private FastCheckoutService fastCheckoutService;
    private BarcodeService barcodeService;

    private JTextField barcodeField;
    private JTextField weightField;
    private JTextArea itemsArea;
    private JLabel totalLabel;
    private JLabel statusLabel;

    public FastCheckoutPanel(FastCheckoutService fastCheckoutService, BarcodeService barcodeService) {
        this.fastCheckoutService = fastCheckoutService;
        this.barcodeService = barcodeService;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createTitledBorder("Caisse Rapide"));

        add(createScanPanel(), BorderLayout.NORTH);
        add(createItemsPanel(), BorderLayout.CENTER);
        add(createActionPanel(), BorderLayout.SOUTH);

        fastCheckoutService.startSession();
    }

    private JPanel createScanPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        panel.setBorder(BorderFactory.createTitledBorder("Scan de produit"));

        panel.add(new JLabel("Code-barre:"));
        barcodeField = new JTextField();
        panel.add(barcodeField);

        panel.add(new JLabel("Poids (kg):"));
        weightField = new JTextField();
        panel.add(weightField);

        JButton scanButton = new JButton("Scanner");
        scanButton.addActionListener(e -> scanProduct());
        panel.add(scanButton);

        statusLabel = new JLabel("Prêt");
        statusLabel.setForeground(Color.GREEN);
        panel.add(statusLabel);

        return panel;
    }

    private JPanel createItemsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Articles"));

        itemsArea = new JTextArea(8, 50);
        itemsArea.setEditable(false);
        itemsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        panel.add(new JScrollPane(itemsArea), BorderLayout.CENTER);

        return panel;
    }

    private JPanel createActionPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));

        totalLabel = new JLabel("Total: 0.00€");
        totalLabel.setFont(new Font(null, Font.BOLD, 16));
        panel.add(totalLabel);

        JButton manualButton = new JButton("Ajouter manuellement");
        manualButton.addActionListener(e -> showManualSelection());
        panel.add(manualButton);

        JButton callButton = new JButton("Appeler caissier");
        callButton.addActionListener(e -> callCashier());
        panel.add(callButton);

        JButton validateButton = new JButton("Valider");
        validateButton.addActionListener(e -> validateCheckout());
        panel.add(validateButton);

        JButton cancelButton = new JButton("Annuler");
        cancelButton.addActionListener(e -> cancel());
        panel.add(cancelButton);

        return panel;
    }

    private void scanProduct() {
        String barcode = barcodeField.getText().trim();
        String weightStr = weightField.getText().trim();

        if (barcode.isEmpty()) {
            statusLabel.setText("Veuillez scanner un code-barre");
            statusLabel.setForeground(Color.RED);
            return;
        }

        try {
            double weight = weightStr.isEmpty() ? 0 : Double.parseDouble(weightStr);
            boolean success = fastCheckoutService.scanProductWithBalance(barcode, weight);

            if (success) {
                statusLabel.setText("Produit ajouté ✓");
                statusLabel.setForeground(Color.GREEN);
            } else if (fastCheckoutService.isBlocked()) {
                statusLabel.setText("⚠️ BLOCAGE - Poids incorrect! Appel caissier requis");
                statusLabel.setForeground(Color.RED);
            } else {
                statusLabel.setText("Produit non trouvé");
                statusLabel.setForeground(Color.RED);
            }

            barcodeField.setText("");
            weightField.setText("");
            updateDisplay();
        } catch (NumberFormatException ex) {
            statusLabel.setText("Poids invalide");
            statusLabel.setForeground(Color.RED);
        }
    }

    private void showManualSelection() {
        String productId = JOptionPane.showInputDialog(this, "ID du produit:");
        if (productId != null && !productId.isEmpty()) {
            String quantityStr = JOptionPane.showInputDialog(this, "Quantité:");
            try {
                int quantity = Integer.parseInt(quantityStr);
                fastCheckoutService.manuallySelectProduct(productId, quantity);
                updateDisplay();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Quantité invalide");
            }
        }
    }

    private void callCashier() {
        fastCheckoutService.callCashier();
        statusLabel.setText("Caissier appelé");
        statusLabel.setForeground(Color.BLUE);
    }

    private void updateDisplay() {
        StringBuilder sb = new StringBuilder();
        fastCheckoutService.getCurrentItems().forEach(item -> {
            sb.append(String.format("%-30s x %3d = %8.2f€\n", 
                    item.getProductName(), (int)item.getQuantity(), item.getTotalPrice()));
        });
        itemsArea.setText(sb.toString());
        totalLabel.setText(String.format("Total: %.2f€", fastCheckoutService.getTotalAmount()));
    }

    private void validateCheckout() {
        if (fastCheckoutService.getCurrentItems().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Aucun article à valider");
            return;
        }
        JOptionPane.showMessageDialog(this, "Transaction validée: " + String.format("%.2f€", fastCheckoutService.getTotalAmount()));
        fastCheckoutService.clearSession();
        updateDisplay();
        statusLabel.setText("Prêt");
        statusLabel.setForeground(Color.GREEN);
    }

    private void cancel() {
        fastCheckoutService.clearSession();
        updateDisplay();
        statusLabel.setText("Annulé");
        statusLabel.setForeground(Color.ORANGE);
        barcodeField.setText("");
        weightField.setText("");
    }
}
