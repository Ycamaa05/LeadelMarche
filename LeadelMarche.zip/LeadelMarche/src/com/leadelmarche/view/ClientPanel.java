package com.leadelmarche.view;

import com.leadelmarche.model.Client;
import com.leadelmarche.service.ClientService;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class ClientPanel extends JPanel {
    private final ClientService clientService;
    private final DefaultTableModel tableModel;
    private final JTable table;
    private final JTextField searchField;

    public ClientPanel(ClientService clientService) {
        this.clientService = clientService;
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(new Color(245, 245, 245));

        JPanel top = new JPanel(new BorderLayout(6, 6));
        top.setBorder(BorderFactory.createTitledBorder("Recherche de Clients"));
        top.setBackground(Color.WHITE);
        searchField = new JTextField();
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 12));
        top.add(new JLabel("🔍 Recherche client :"), BorderLayout.WEST);
        top.add(searchField, BorderLayout.CENTER);
        JButton searchButton = new JButton("Chercher");
        searchButton.setBackground(new Color(70, 130, 180));
        searchButton.setForeground(Color.WHITE);
        searchButton.setFocusPainted(false);
        top.add(searchButton, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"ID", "Prénom", "Nom", "Carte fidélité", "Mail", "Code postal", "Actif"}, 0);
        table = new JTable(tableModel);
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        table.setFont(new Font("SansSerif", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel buttons = new JPanel(new GridLayout(1, 3, 10, 10));
        buttons.setBorder(new EmptyBorder(10, 0, 0, 0));
        JButton createButton = new JButton("➕ Ajouter");
        createButton.setToolTipText("Ajouter un nouveau client (Ctrl+N)");
        createButton.setMnemonic('N');
        createButton.setBackground(new Color(34, 139, 34));
        createButton.setForeground(Color.WHITE);
        createButton.setFocusPainted(false);
        JButton editButton = new JButton("✏️ Modifier");
        editButton.setToolTipText("Modifier le client sélectionné (Ctrl+E)");
        editButton.setMnemonic('E');
        editButton.setBackground(new Color(255, 165, 0));
        editButton.setForeground(Color.WHITE);
        editButton.setFocusPainted(false);
        JButton deleteButton = new JButton("❌ Désactiver");
        deleteButton.setToolTipText("Désactiver le client sélectionné (Ctrl+D)");
        deleteButton.setMnemonic('D');
        deleteButton.setBackground(new Color(220, 20, 60));
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setFocusPainted(false);
        buttons.add(createButton);
        buttons.add(editButton);
        buttons.add(deleteButton);
        add(buttons, BorderLayout.SOUTH);

        searchButton.addActionListener(e -> loadClients(searchField.getText()));
        createButton.addActionListener(e -> openEditor(null));
        editButton.addActionListener(e -> editSelectedClient());
        deleteButton.addActionListener(e -> deactivateSelectedClient());

        loadClients("");
    }

    private void loadClients(String search) {
        try {
            List<Client> list = search.isBlank() ? clientService.getActiveClients() : clientService.search(search);
            tableModel.setRowCount(0);
            for (Client client : list) {
                tableModel.addRow(new Object[]{client.getId(), client.getFirstName(), client.getLastName(), client.getLoyaltyCardNumber(), client.getEmail(), client.getPostalCode(), client.isActive()});
            }
        } catch (Exception e) {
            showError(e);
        }
    }

    private void openEditor(Client existing) {
        try {
            ClientEditor editor = new ClientEditor(existing);
            int result = JOptionPane.showConfirmDialog(this, editor.getPanel(), existing == null ? "Ajouter client" : "Modifier client", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (result == JOptionPane.OK_OPTION) {
                Client client = editor.buildClient();
                if (existing == null) {
                    clientService.addClient(client);
                } else {
                    clientService.updateClient(client);
                }
                loadClients("");
            }
        } catch (Exception e) {
            showError(e);
        }
    }

    private void editSelectedClient() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un client.");
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        clientService.findById(id).ifPresent(this::openEditor);
    }

    private void deactivateSelectedClient() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un client à désactiver.", "Aucune sélection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        String firstName = (String) tableModel.getValueAt(row, 1);
        String lastName = (String) tableModel.getValueAt(row, 2);

        int confirm = JOptionPane.showConfirmDialog(this,
            "Êtes-vous sûr de vouloir désactiver le client :\n" + firstName + " " + lastName + " (ID: " + id + ") ?",
            "Confirmation de désactivation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                clientService.deactivateClient(id);
                loadClients("");
                JOptionPane.showMessageDialog(this, "Client désactivé avec succès.", "Succès", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                showError(e);
            }
        }
    }

    private void showError(Exception e) {
        JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
    }

    private class ClientEditor {
        private final JPanel panel;
        private final JTextField firstNameField;
        private final JTextField lastNameField;
        private final JTextField loyaltyField;
        private final JTextField emailField;
        private final JTextField postalField;

        ClientEditor(Client existing) {
            panel = new JPanel(new GridLayout(6, 2, 4, 4));
            firstNameField = new JTextField();
            lastNameField = new JTextField();
            loyaltyField = new JTextField();
            emailField = new JTextField();
            postalField = new JTextField();

            panel.add(new JLabel("Prénom :")); panel.add(firstNameField);
            panel.add(new JLabel("Nom :")); panel.add(lastNameField);
            panel.add(new JLabel("Carte fidélité :")); panel.add(loyaltyField);
            panel.add(new JLabel("Email :")); panel.add(emailField);
            panel.add(new JLabel("Code postal :")); panel.add(postalField);

            if (existing != null) {
                firstNameField.setText(existing.getFirstName());
                lastNameField.setText(existing.getLastName());
                loyaltyField.setText(existing.getLoyaltyCardNumber());
                emailField.setText(existing.getEmail());
                postalField.setText(existing.getPostalCode());
            }
        }

        JPanel getPanel() {
            return panel;
        }

        Client buildClient() {
            String id = (table.getSelectedRow() >= 0) ? (String) tableModel.getValueAt(table.getSelectedRow(), 0) : java.util.UUID.randomUUID().toString();
            return new Client(id, firstNameField.getText(), lastNameField.getText(), loyaltyField.getText(), emailField.getText(), postalField.getText(), true);
        }
    }
}
