package com.leadelmarche.view;

import com.leadelmarche.model.Product;
import com.leadelmarche.service.StockAlertService;
import com.leadelmarche.service.StoreService;
import java.awt.*;
import java.util.List;
import javax.swing.*;

public class StockManagementPanel extends JPanel {
    private StockAlertService stockAlertService;
    private StoreService storeService;

    private JTextArea alertArea;
    private JLabel alertCountLabel;

    public StockManagementPanel(StockAlertService stockAlertService, StoreService storeService) {
        this.stockAlertService = stockAlertService;
        this.storeService = storeService;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createTitledBorder("Gestion des Stocks"));

        add(createControlPanel(), BorderLayout.NORTH);
        add(createAlertPanel(), BorderLayout.CENTER);
        add(createActionPanel(), BorderLayout.SOUTH);

        refreshAlerts();
    }

    private JPanel createControlPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panel.setBorder(BorderFactory.createTitledBorder("Contrôle des stocks"));

        JButton refreshButton = new JButton("Actualiser");
        refreshButton.addActionListener(e -> refreshAlerts());
        panel.add(refreshButton);

        JButton checkButton = new JButton("Vérifier stocks bas");
        checkButton.addActionListener(e -> stockAlertService.checkAndAlertLowStock());
        panel.add(checkButton);

        alertCountLabel = new JLabel("Produits en alerte: 0");
        alertCountLabel.setFont(new Font(null, Font.BOLD, 12));
        panel.add(alertCountLabel);

        return panel;
    }

    private JPanel createAlertPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        alertArea = new JTextArea();
        alertArea.setEditable(false);
        alertArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        panel.add(new JScrollPane(alertArea), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createActionPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton storesButton = new JButton("Consulter autres magasins");
        storesButton.addActionListener(e -> showOtherStores());
        panel.add(storesButton);

        JButton orderButton = new JButton("Passer commande");
        orderButton.addActionListener(e -> placeOrder());
        panel.add(orderButton);

        return panel;
    }

    private void refreshAlerts() {
        List<Product> lowStockProducts = stockAlertService.getProductsWithLowStock();
        String report = stockAlertService.generateStockAlertReport();
        
        alertArea.setText(report);
        alertCountLabel.setText("Produits en alerte: " + lowStockProducts.size());
        
        if (lowStockProducts.size() > 0) {
            alertCountLabel.setForeground(new Color(255, 100, 0));
        } else {
            alertCountLabel.setForeground(Color.GREEN);
        }
    }

    private void showOtherStores() {
        StringBuilder msg = new StringBuilder("Autres magasins disponibles:\n\n");
        
        storeService.getActiveLocations().forEach(store -> {
            msg.append("• ").append(store.getName()).append("\n");
            msg.append("  Ville: ").append(store.getCity()).append("\n");
            msg.append("  Adresse: ").append(store.getAddress()).append("\n");
            msg.append("  Tél: ").append(store.getPhone()).append("\n\n");
        });

        JTextArea textArea = new JTextArea(msg.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Autres points de vente", JOptionPane.INFORMATION_MESSAGE);
    }

    private void placeOrder() {
        List<Product> products = stockAlertService.getProductsWithLowStock();
        if (products.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Aucun produit en stock bas");
            return;
        }

        StringBuilder order = new StringBuilder("Commande suggérée:\n\n");
        products.forEach(p -> {
            order.append("- ").append(p.getName()).append(" (").append(p.getSupplierName()).append(")\n");
        });

        JTextArea textArea = new JTextArea(order.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        
        int result = JOptionPane.showConfirmDialog(this, scrollPane, "Confirmer commande", 
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        
        if (result == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Commande placée avec succès!");
        }
    }
}
